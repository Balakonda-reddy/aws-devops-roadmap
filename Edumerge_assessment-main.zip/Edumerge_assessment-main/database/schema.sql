-- MySQL Database Schema for Admission Management System

-- CREATE DATABASE IF NOT EXISTS admission_management;
USE admission_management;

-- Users table
CREATE TABLE users (
    id INT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(80) NOT NULL UNIQUE,
    email VARCHAR(120) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    role ENUM('admin', 'admission_officer', 'management') NOT NULL,
    is_active BOOLEAN DEFAULT TRUE,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Institutions table
CREATE TABLE institutions (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(200) NOT NULL,
    code VARCHAR(20) NOT NULL UNIQUE,
    address TEXT,
    is_active BOOLEAN DEFAULT TRUE,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Campuses table
CREATE TABLE campuses (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(200) NOT NULL,
    code VARCHAR(20) NOT NULL,
    institution_id INT NOT NULL,
    location VARCHAR(200),
    is_active BOOLEAN DEFAULT TRUE,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (institution_id) REFERENCES institutions(id)
);

-- Departments table
CREATE TABLE departments (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(200) NOT NULL,
    code VARCHAR(20) NOT NULL,
    campus_id INT NOT NULL,
    is_active BOOLEAN DEFAULT TRUE,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (campus_id) REFERENCES campuses(id)
);

-- Academic Years table
CREATE TABLE academic_years (
    id INT PRIMARY KEY AUTO_INCREMENT,
    year VARCHAR(20) NOT NULL UNIQUE,
    start_date DATE NOT NULL,
    end_date DATE NOT NULL,
    is_active BOOLEAN DEFAULT FALSE,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Programs table
CREATE TABLE programs (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(200) NOT NULL,
    code VARCHAR(20) NOT NULL,
    department_id INT NOT NULL,
    academic_year_id INT NOT NULL,
    course_type ENUM('UG', 'PG') NOT NULL,
    entry_type ENUM('Regular', 'Lateral') NOT NULL,
    total_intake INT NOT NULL,
    is_active BOOLEAN DEFAULT TRUE,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (department_id) REFERENCES departments(id),
    FOREIGN KEY (academic_year_id) REFERENCES academic_years(id)
);

-- Quotas table
CREATE TABLE quotas (
    id INT PRIMARY KEY AUTO_INCREMENT,
    program_id INT NOT NULL,
    quota_type ENUM('KCET', 'COMEDK', 'Management') NOT NULL,
    seats_allocated INT NOT NULL,
    seats_filled INT DEFAULT 0,
    is_active BOOLEAN DEFAULT TRUE,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (program_id) REFERENCES programs(id),
    UNIQUE KEY unique_program_quota (program_id, quota_type)
);

-- Applicants table
CREATE TABLE applicants (
    id INT PRIMARY KEY AUTO_INCREMENT,
    first_name VARCHAR(100) NOT NULL,
    last_name VARCHAR(100) NOT NULL,
    email VARCHAR(120) NOT NULL UNIQUE,
    phone VARCHAR(15) NOT NULL,
    date_of_birth DATE NOT NULL,
    gender ENUM('Male', 'Female', 'Other') NOT NULL,
    category ENUM('GM', 'SC', 'ST', 'OBC', '2A', '2B', '3A', '3B') NOT NULL,
    address TEXT NOT NULL,
    guardian_name VARCHAR(200) NOT NULL,
    guardian_phone VARCHAR(15) NOT NULL,
    qualifying_exam VARCHAR(100) NOT NULL,
    marks_obtained FLOAT NOT NULL,
    total_marks FLOAT NOT NULL,
    program_id INT NOT NULL,
    quota_id INT,
    entry_type ENUM('Regular', 'Lateral') NOT NULL,
    allotment_number VARCHAR(50),
    application_status ENUM('Applied', 'Document_Pending', 'Document_Submitted', 'Document_Verified', 'Seat_Allocated', 'Admission_Confirmed') DEFAULT 'Applied',
    document_status ENUM('Pending', 'Submitted', 'Verified') DEFAULT 'Pending',
    fee_status ENUM('Pending', 'Paid') DEFAULT 'Pending',
    admission_number VARCHAR(50) UNIQUE,
    admission_date DATETIME,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (program_id) REFERENCES programs(id),
    FOREIGN KEY (quota_id) REFERENCES quotas(id)
);

-- Admission Logs table
CREATE TABLE admission_logs (
    id INT PRIMARY KEY AUTO_INCREMENT,
    applicant_id INT NOT NULL,
    action VARCHAR(100) NOT NULL,
    old_status VARCHAR(50),
    new_status VARCHAR(50) NOT NULL,
    performed_by INT NOT NULL,
    notes TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (applicant_id) REFERENCES applicants(id),
    FOREIGN KEY (performed_by) REFERENCES users(id)
);

-- Create indexes for better performance
CREATE INDEX idx_applicants_program ON applicants(program_id);
CREATE INDEX idx_applicants_quota ON applicants(quota_id);
CREATE INDEX idx_applicants_status ON applicants(application_status);
CREATE INDEX idx_applicants_email ON applicants(email);
CREATE INDEX idx_quotas_program ON quotas(program_id);
CREATE INDEX idx_admission_logs_applicant ON admission_logs(applicant_id);

 
    

// ...existing code...DELETE FROM users WHERE username IN ('admin', 'officer', 'management');

INSERT INTO users (username, email, password_hash, role) VALUES 
('admin', 'admin@college.edu', 'scrypt:32768:8:1$abcdef1234567890$1234567890abcdef1234567890abcdef1234567890abcdef1234567890abcdef', 'admin'),
('officer', 'officer@college.edu', 'scrypt:32768:8:1$abcdef1234567890$1234567890abcdef1234567890abcdef1234567890abcdef1234567890abcdef', 'admission_officer'),
('management', 'management@college.edu', 'scrypt:32768:8:1$abcdef1234567890$1234567890abcdef1234567890abcdef1234567890abcdef1234567890abcdef', 'management');