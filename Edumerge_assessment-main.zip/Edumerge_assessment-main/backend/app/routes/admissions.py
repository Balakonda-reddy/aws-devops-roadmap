from flask import Blueprint, request, jsonify
from app import db
from app.models.admission import Applicant, AdmissionLog, Quota
from app.models import Program, Institution
from datetime import datetime
import re
from datetime import datetime
import re

bp = Blueprint('admissions', __name__, url_prefix='/api/admissions')

def generate_admission_number(applicant, quota):
    """
    Generate admission number in format: INST/2026/UG/CSE/KCET/0001
    """
    try:
        program = applicant.program
        department = program.department
        campus = department.campus
        institution = campus.institution
        
        # Get year from academic year
        year = program.academic_year.year.split('-')[0]
        
        # Count existing admissions for this program and quota
        existing_count = Applicant.query.filter(
            Applicant.program_id == program.id,
            Applicant.quota_id == quota.id,
            Applicant.admission_number.isnot(None)
        ).count()
        
        sequence = str(existing_count + 1).zfill(4)
        
        admission_number = f"{institution.code}/{year}/{program.course_type}/{department.code}/{quota.quota_type}/{sequence}"
        
        return admission_number
        
    except Exception as e:
        raise Exception(f"Error generating admission number: {str(e)}")

@bp.route('/allocate-seat', methods=['POST'])
def allocate_seat():
    """
    Allocate seat to an applicant
    """
    try:
        data = request.get_json()
        
        required_fields = ['applicant_id', 'quota_id']
        for field in required_fields:
            if not data.get(field):
                return jsonify({'error': f'{field} is required'}), 400
        
        applicant = Applicant.query.get(data['applicant_id'])
        if not applicant:
            return jsonify({'error': 'Applicant not found'}), 404
        
        quota = Quota.query.get(data['quota_id'])
        if not quota:
            return jsonify({'error': 'Quota not found'}), 404
        
        # Verify quota belongs to applicant's program
        if quota.program_id != applicant.program_id:
            return jsonify({'error': 'Quota does not belong to applicant program'}), 400
        
        # Check if applicant is eligible for seat allocation
        if applicant.application_status not in ['Applied', 'Document_Verified']:
            return jsonify({'error': 'Applicant not eligible for seat allocation'}), 400
        
        # Check if applicant already has a seat
        if applicant.quota_id:
            return jsonify({'error': 'Applicant already has an allocated seat'}), 400
        
        # Check quota availability
        if quota.remaining_seats <= 0:
            return jsonify({'error': 'No seats available in this quota'}), 400
        
        # For government flow, allotment number is required
        if quota.quota_type in ['KCET', 'COMEDK'] and not applicant.allotment_number:
            return jsonify({'error': 'Allotment number required for government quota'}), 400
        
        # Allocate seat
        applicant.quota_id = quota.id
        applicant.application_status = 'Seat_Allocated'
        applicant.updated_at = datetime.utcnow()
        
        # Update quota count
        quota.seats_filled += 1
        
        db.session.commit()
        
        # Log the action
        log = AdmissionLog(
            applicant_id=applicant.id,
            action='Seat Allocated',
            old_status='Document_Verified',
            new_status='Seat_Allocated',
            performed_by=1,  # Default user ID for demo
            notes=f'Seat allocated in {quota.quota_type} quota'
        )
        db.session.add(log)
        db.session.commit()
        
        return jsonify({
            'message': 'Seat allocated successfully',
            'applicant': applicant.to_dict(),
            'quota': quota.to_dict()
        }), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@bp.route('/confirm-admission', methods=['POST'])
def confirm_admission():
    """
    Confirm admission after fee payment
    """
    try:
        data = request.get_json()
        
        required_fields = ['applicant_id', 'fee_status']
        for field in required_fields:
            if not data.get(field):
                return jsonify({'error': f'{field} is required'}), 400
        
        applicant = Applicant.query.get(data['applicant_id'])
        if not applicant:
            return jsonify({'error': 'Applicant not found'}), 404
        
        # Check if seat is allocated
        if not applicant.quota_id or applicant.application_status != 'Seat_Allocated':
            return jsonify({'error': 'Seat must be allocated before confirmation'}), 400
        
        # Check if already confirmed
        if applicant.admission_number:
            return jsonify({'error': 'Admission already confirmed'}), 400
        
        # Validate fee status
        if data['fee_status'] not in ['Pending', 'Paid']:
            return jsonify({'error': 'Invalid fee status'}), 400
        
        # Fee must be paid for confirmation
        if data['fee_status'] != 'Paid':
            return jsonify({'error': 'Fee must be paid for admission confirmation'}), 400
        
        # Update applicant
        old_status = applicant.application_status
        applicant.fee_status = data['fee_status']
        applicant.application_status = 'Admission_Confirmed'
        applicant.admission_date = datetime.utcnow()
        applicant.updated_at = datetime.utcnow()
        
        # Generate admission number
        try:
            admission_number = generate_admission_number(applicant, applicant.quota)
            applicant.admission_number = admission_number
        except Exception as e:
            return jsonify({'error': f'Failed to generate admission number: {str(e)}'}), 500
        
        db.session.commit()
        
        # Log the action
        log = AdmissionLog(
            applicant_id=applicant.id,
            action='Admission Confirmed',
            old_status=old_status,
            new_status='Admission_Confirmed',
            performed_by=1,  # Default user ID for demo
            notes=f'Admission confirmed with number: {admission_number}'
        )
        db.session.add(log)
        db.session.commit()
        
        return jsonify({
            'message': 'Admission confirmed successfully',
            'applicant': applicant.to_dict(),
            'admission_number': admission_number
        }), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@bp.route('/update-fee-status', methods=['POST'])
def update_fee_status():
    """
    Update fee payment status
    """
    try:
        data = request.get_json()
        
        required_fields = ['applicant_id', 'fee_status']
        for field in required_fields:
            if not data.get(field):
                return jsonify({'error': f'{field} is required'}), 400
        
        applicant = Applicant.query.get(data['applicant_id'])
        if not applicant:
            return jsonify({'error': 'Applicant not found'}), 404
        
        if data['fee_status'] not in ['Pending', 'Paid']:
            return jsonify({'error': 'Invalid fee status'}), 400
        
        old_fee_status = applicant.fee_status
        applicant.fee_status = data['fee_status']
        applicant.updated_at = datetime.utcnow()
        
        db.session.commit()
        
        # Log the action
        log = AdmissionLog(
            applicant_id=applicant.id,
            action='Fee Status Updated',
            old_status=old_fee_status,
            new_status=data['fee_status'],
            performed_by=1,  # Default user ID for demo
            notes=f'Fee status changed from {old_fee_status} to {data["fee_status"]}'
        )
        db.session.add(log)
        db.session.commit()
        
        return jsonify({
            'message': 'Fee status updated successfully',
            'applicant': applicant.to_dict()
        }), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@bp.route('/available-seats/<int:program_id>', methods=['GET'])
def get_available_seats(program_id):
    """
    Get available seats for a program by quota
    """
    try:
        program = Program.query.get(program_id)
        if not program:
            return jsonify({'error': 'Program not found'}), 404
        
        quotas = Quota.query.filter_by(program_id=program_id, is_active=True).all()
        
        quota_info = []
        for quota in quotas:
            quota_info.append({
                'quota_id': quota.id,
                'quota_type': quota.quota_type,
                'seats_allocated': quota.seats_allocated,
                'seats_filled': quota.seats_filled,
                'remaining_seats': quota.remaining_seats
            })
        
        return jsonify({
            'program': program.to_dict(),
            'quotas': quota_info,
            'total_intake': program.total_intake,
            'total_allocated': sum(q.seats_allocated for q in quotas),
            'total_filled': sum(q.seats_filled for q in quotas)
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500