from flask import Blueprint, request, jsonify
from app import db
from app.models.admission import Applicant, AdmissionLog
from app.models import Program, Quota
from datetime import datetime
from datetime import datetime

bp = Blueprint('applicants', __name__, url_prefix='/api/applicants')

@bp.route('', methods=['POST'])
def create_applicant():
    try:
        data = request.get_json()
        
        # Required fields validation
        required_fields = [
            'first_name', 'last_name', 'email', 'phone', 'date_of_birth',
            'gender', 'category', 'address', 'guardian_name', 'guardian_phone',
            'qualifying_exam', 'marks_obtained', 'total_marks', 'program_id',
            'entry_type'
        ]
        
        for field in required_fields:
            if not data.get(field):
                return jsonify({'error': f'{field} is required'}), 400
        
        # Validate email uniqueness
        if Applicant.query.filter_by(email=data['email']).first():
            return jsonify({'error': 'Email already exists'}), 409
        
        # Validate program exists
        program = Program.query.get(data['program_id'])
        if not program:
            return jsonify({'error': 'Program not found'}), 404
        
        # Validate enum values
        if data['gender'] not in ['Male', 'Female', 'Other']:
            return jsonify({'error': 'Invalid gender'}), 400
        
        if data['category'] not in ['GM', 'SC', 'ST', 'OBC', '2A', '2B', '3A', '3B']:
            return jsonify({'error': 'Invalid category'}), 400
        
        if data['entry_type'] not in ['Regular', 'Lateral']:
            return jsonify({'error': 'Invalid entry type'}), 400
        
        # Create applicant
        applicant = Applicant(
            first_name=data['first_name'],
            last_name=data['last_name'],
            email=data['email'],
            phone=data['phone'],
            date_of_birth=datetime.strptime(data['date_of_birth'], '%Y-%m-%d').date(),
            gender=data['gender'],
            category=data['category'],
            address=data['address'],
            guardian_name=data['guardian_name'],
            guardian_phone=data['guardian_phone'],
            qualifying_exam=data['qualifying_exam'],
            marks_obtained=float(data['marks_obtained']),
            total_marks=float(data['total_marks']),
            program_id=data['program_id'],
            entry_type=data['entry_type'],
            allotment_number=data.get('allotment_number')
        )
        
        db.session.add(applicant)
        db.session.commit()
        
        # Log the action
        log = AdmissionLog(
            applicant_id=applicant.id,
            action='Application Created',
            new_status='Applied',
            performed_by=1,  # Default user ID for demo
            notes='New application submitted'
        )
        db.session.add(log)
        db.session.commit()
        
        return jsonify({
            'message': 'Applicant created successfully',
            'applicant': applicant.to_dict()
        }), 201
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@bp.route('', methods=['GET'])
def get_applicants():
    try:
        page = request.args.get('page', 1, type=int)
        per_page = request.args.get('per_page', 10, type=int)
        program_id = request.args.get('program_id')
        status = request.args.get('status')
        search = request.args.get('search')
        
        query = Applicant.query
        
        # Apply filters
        if program_id:
            query = query.filter_by(program_id=program_id)
        
        if status:
            query = query.filter_by(application_status=status)
        
        if search:
            query = query.filter(
                db.or_(
                    Applicant.first_name.contains(search),
                    Applicant.last_name.contains(search),
                    Applicant.email.contains(search),
                    Applicant.phone.contains(search),
                    Applicant.admission_number.contains(search) if search else False
                )
            )
        
        # Paginate
        pagination = query.paginate(
            page=page, per_page=per_page, error_out=False
        )
        
        applicants = pagination.items
        
        return jsonify({
            'applicants': [applicant.to_dict() for applicant in applicants],
            'pagination': {
                'page': page,
                'per_page': per_page,
                'total': pagination.total,
                'pages': pagination.pages,
                'has_next': pagination.has_next,
                'has_prev': pagination.has_prev
            }
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@bp.route('/<int:applicant_id>', methods=['GET'])
def get_applicant(applicant_id):
    try:
        applicant = Applicant.query.get(applicant_id)
        if not applicant:
            return jsonify({'error': 'Applicant not found'}), 404
        
        return jsonify({'applicant': applicant.to_dict()}), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@bp.route('/<int:applicant_id>', methods=['PUT'])
def update_applicant(applicant_id):
    try:
        applicant = Applicant.query.get(applicant_id)
        if not applicant:
            return jsonify({'error': 'Applicant not found'}), 404
        
        data = request.get_json()
        
        # Store old status for logging
        old_status = applicant.application_status
        
        # Update allowed fields
        updateable_fields = [
            'first_name', 'last_name', 'phone', 'address', 
            'guardian_name', 'guardian_phone'
        ]
        
        for field in updateable_fields:
            if field in data:
                setattr(applicant, field, data[field])
        
        applicant.updated_at = datetime.utcnow()
        
        db.session.commit()
        
        # Log if there were changes
        if any(field in data for field in updateable_fields):
            log = AdmissionLog(
                applicant_id=applicant_id,
                action='Applicant Updated',
                old_status=old_status,
                new_status=applicant.application_status,
                performed_by=1,  # Default user ID for demo
                notes='Applicant information updated'
            )
            db.session.add(log)
            db.session.commit()
        
        return jsonify({
            'message': 'Applicant updated successfully',
            'applicant': applicant.to_dict()
        }), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@bp.route('/<int:applicant_id>/documents', methods=['PUT'])
def update_document_status(applicant_id):
    try:
        applicant = Applicant.query.get(applicant_id)
        if not applicant:
            return jsonify({'error': 'Applicant not found'}), 404
        
        data = request.get_json()
        
        if 'document_status' not in data:
            return jsonify({'error': 'document_status is required'}), 400
        
        if data['document_status'] not in ['Pending', 'Submitted', 'Verified']:
            return jsonify({'error': 'Invalid document status'}), 400
        
        old_status = applicant.document_status
        applicant.document_status = data['document_status']
        
        # Update application status based on document status
        if data['document_status'] == 'Submitted':
            applicant.application_status = 'Document_Submitted'
        elif data['document_status'] == 'Verified':
            applicant.application_status = 'Document_Verified'
        
        applicant.updated_at = datetime.utcnow()
        
        db.session.commit()
        
        # Log the action
        log = AdmissionLog(
            applicant_id=applicant_id,
            action='Document Status Updated',
            old_status=old_status,
            new_status=applicant.document_status,
            performed_by=1,  # Default user ID for demo
            notes=data.get('notes', 'Document status updated')
        )
        db.session.add(log)
        db.session.commit()
        
        return jsonify({
            'message': 'Document status updated successfully',
            'applicant': applicant.to_dict()
        }), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@bp.route('/<int:applicant_id>/logs', methods=['GET'])
def get_applicant_logs(applicant_id):
    try:
        applicant = Applicant.query.get(applicant_id)
        if not applicant:
            return jsonify({'error': 'Applicant not found'}), 404
        
        logs = AdmissionLog.query.filter_by(applicant_id=applicant_id)\
                                .order_by(AdmissionLog.created_at.desc()).all()
        
        return jsonify({
            'logs': [log.to_dict() for log in logs]
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500