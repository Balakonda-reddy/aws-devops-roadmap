from flask import Blueprint, request, jsonify
from sqlalchemy import func
from app import db
from app.models import Program, AcademicYear
from app.models.admission import Applicant, Quota

bp = Blueprint('dashboard', __name__, url_prefix='/api/dashboard')

@bp.route('/overview', methods=['GET'])
def get_overview():
    """
    Get overview dashboard data
    """
    try:
        academic_year_id = request.args.get('academic_year_id')
        program_id = request.args.get('program_id')
        
        # Base query
        if academic_year_id:
            programs = Program.query.filter_by(academic_year_id=academic_year_id, is_active=True)
        else:
            # Get current active academic year
            active_year = AcademicYear.query.filter_by(is_active=True).first()
            if active_year:
                programs = Program.query.filter_by(academic_year_id=active_year.id, is_active=True)
            else:
                programs = Program.query.filter_by(is_active=True)
        
        if program_id:
            programs = programs.filter_by(id=program_id)
        
        programs = programs.all()
        
        # Initialize totals
        total_intake = 0
        total_allocated = 0
        total_filled = 0
        program_stats = []
        
        for program in programs:
            program_intake = program.total_intake
            program_quotas = Quota.query.filter_by(program_id=program.id, is_active=True).all()
            
            program_allocated = sum(q.seats_allocated for q in program_quotas)
            program_filled = sum(q.seats_filled for q in program_quotas)
            
            quota_breakdown = []
            for quota in program_quotas:
                quota_breakdown.append({
                    'quota_type': quota.quota_type,
                    'allocated': quota.seats_allocated,
                    'filled': quota.seats_filled,
                    'remaining': quota.remaining_seats
                })
            
            program_stats.append({
                'program_id': program.id,
                'program_name': program.name,
                'program_code': program.code,
                'department': program.department.name,
                'course_type': program.course_type,
                'entry_type': program.entry_type,
                'total_intake': program_intake,
                'total_allocated': program_allocated,
                'total_filled': program_filled,
                'remaining_seats': program_allocated - program_filled,
                'quota_breakdown': quota_breakdown
            })
            
            total_intake += program_intake
            total_allocated += program_allocated
            total_filled += program_filled
        
        # Get application statistics
        applicant_query = db.session.query(
            Applicant.application_status,
            func.count(Applicant.id).label('count')
        )
        
        if program_id:
            applicant_query = applicant_query.filter_by(program_id=program_id)
        elif programs:
            program_ids = [p.id for p in programs]
            applicant_query = applicant_query.filter(Applicant.program_id.in_(program_ids))
        
        application_stats = applicant_query.group_by(Applicant.application_status).all()
        
        # Get document status statistics
        document_query = db.session.query(
            Applicant.document_status,
            func.count(Applicant.id).label('count')
        )
        
        if program_id:
            document_query = document_query.filter_by(program_id=program_id)
        elif programs:
            program_ids = [p.id for p in programs]
            document_query = document_query.filter(Applicant.program_id.in_(program_ids))
        
        document_stats = document_query.group_by(Applicant.document_status).all()
        
        # Get fee status statistics
        fee_query = db.session.query(
            Applicant.fee_status,
            func.count(Applicant.id).label('count')
        )
        
        if program_id:
            fee_query = fee_query.filter_by(program_id=program_id)
        elif programs:
            program_ids = [p.id for p in programs]
            fee_query = fee_query.filter(Applicant.program_id.in_(program_ids))
        
        fee_stats = fee_query.group_by(Applicant.fee_status).all()
        
        return jsonify({
            'overview': {
                'total_intake': total_intake,
                'total_allocated': total_allocated,
                'total_filled': total_filled,
                'total_remaining': total_allocated - total_filled,
                'fill_percentage': (total_filled / total_allocated * 100) if total_allocated > 0 else 0
            },
            'program_stats': program_stats,
            'application_stats': [{'status': stat.application_status, 'count': stat.count} for stat in application_stats],
            'document_stats': [{'status': stat.document_status, 'count': stat.count} for stat in document_stats],
            'fee_stats': [{'status': stat.fee_status, 'count': stat.count} for stat in fee_stats]
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@bp.route('/pending-actions', methods=['GET'])
def get_pending_actions():
    """
    Get list of pending actions/tasks
    """
    try:
        # Applicants with pending documents
        pending_documents = Applicant.query.filter_by(document_status='Pending').count()
        
        # Applicants with submitted documents (need verification)
        submitted_documents = Applicant.query.filter_by(document_status='Submitted').count()
        
        # Applicants with allocated seats but pending fees
        pending_fees = Applicant.query.filter(
            Applicant.application_status == 'Seat_Allocated',
            Applicant.fee_status == 'Pending'
        ).count()
        
        # Applicants ready for seat allocation (documents verified)
        ready_for_allocation = Applicant.query.filter_by(
            application_status='Document_Verified',
            quota_id=None
        ).count()
        
        # Get detailed lists if requested
        include_details = request.args.get('include_details', 'false').lower() == 'true'
        
        response = {
            'pending_counts': {
                'pending_documents': pending_documents,
                'submitted_documents': submitted_documents,
                'pending_fees': pending_fees,
                'ready_for_allocation': ready_for_allocation
            }
        }
        
        if include_details:
            # Get actual lists
            response['details'] = {
                'pending_documents': [
                    applicant.to_dict() 
                    for applicant in Applicant.query.filter_by(document_status='Pending').limit(10).all()
                ],
                'submitted_documents': [
                    applicant.to_dict() 
                    for applicant in Applicant.query.filter_by(document_status='Submitted').limit(10).all()
                ],
                'pending_fees': [
                    applicant.to_dict() 
                    for applicant in Applicant.query.filter(
                        Applicant.application_status == 'Seat_Allocated',
                        Applicant.fee_status == 'Pending'
                    ).limit(10).all()
                ],
                'ready_for_allocation': [
                    applicant.to_dict() 
                    for applicant in Applicant.query.filter_by(
                        application_status='Document_Verified',
                        quota_id=None
                    ).limit(10).all()
                ]
            }
        
        return jsonify(response), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@bp.route('/quota-wise-stats', methods=['GET'])
def get_quota_wise_stats():
    """
    Get quota-wise statistics across all programs
    """
    try:
        academic_year_id = request.args.get('academic_year_id')
        
        quota_query = db.session.query(
            Quota.quota_type,
            func.sum(Quota.seats_allocated).label('total_allocated'),
            func.sum(Quota.seats_filled).label('total_filled')
        )
        
        if academic_year_id:
            quota_query = quota_query.join(Program).filter(Program.academic_year_id == academic_year_id)
        
        quota_stats = quota_query.group_by(Quota.quota_type).all()
        
        quota_breakdown = []
        for stat in quota_stats:
            remaining = stat.total_allocated - stat.total_filled
            fill_percentage = (stat.total_filled / stat.total_allocated * 100) if stat.total_allocated > 0 else 0
            
            quota_breakdown.append({
                'quota_type': stat.quota_type,
                'total_allocated': stat.total_allocated,
                'total_filled': stat.total_filled,
                'remaining': remaining,
                'fill_percentage': fill_percentage
            })
        
        return jsonify({
            'quota_stats': quota_breakdown
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@bp.route('/recent-admissions', methods=['GET'])
def get_recent_admissions():
    """
    Get recently confirmed admissions
    """
    try:
        limit = request.args.get('limit', 10, type=int)
        
        recent_admissions = Applicant.query.filter(
            Applicant.admission_number.isnot(None)
        ).order_by(Applicant.admission_date.desc()).limit(limit).all()
        
        return jsonify({
            'recent_admissions': [
                {
                    'id': applicant.id,
                    'full_name': applicant.full_name,
                    'admission_number': applicant.admission_number,
                    'program': applicant.program.name,
                    'quota_type': applicant.quota.quota_type if applicant.quota else None,
                    'admission_date': applicant.admission_date.isoformat() if applicant.admission_date else None
                }
                for applicant in recent_admissions
            ]
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500