from flask import Blueprint, request, jsonify
from app import db
from app.models import Institution, Campus, Department, Program, AcademicYear, Quota
from datetime import datetime
from datetime import datetime

bp = Blueprint('masters', __name__, url_prefix='/api/masters')

# Institution Management
@bp.route('/institutions', methods=['POST'])
def create_institution():
    try:
        data = request.get_json()
        
        required_fields = ['name', 'code']
        for field in required_fields:
            if not data.get(field):
                return jsonify({'error': f'{field} is required'}), 400
        
        # Check if institution code exists
        if Institution.query.filter_by(code=data['code']).first():
            return jsonify({'error': 'Institution code already exists'}), 409
        
        institution = Institution(
            name=data['name'],
            code=data['code'],
            address=data.get('address', '')
        )
        
        db.session.add(institution)
        db.session.commit()
        
        return jsonify({
            'message': 'Institution created successfully',
            'institution': institution.to_dict()
        }), 201
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@bp.route('/institutions', methods=['GET'])
def get_institutions():
    try:
        institutions = Institution.query.filter_by(is_active=True).all()
        return jsonify({
            'institutions': [inst.to_dict() for inst in institutions]
        }), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# Campus Management
@bp.route('/campuses', methods=['POST'])
def create_campus():
    try:
        data = request.get_json()
        
        required_fields = ['name', 'code', 'institution_id']
        for field in required_fields:
            if not data.get(field):
                return jsonify({'error': f'{field} is required'}), 400
        
        # Verify institution exists
        institution = Institution.query.get(data['institution_id'])
        if not institution:
            return jsonify({'error': 'Institution not found'}), 404
        
        campus = Campus(
            name=data['name'],
            code=data['code'],
            institution_id=data['institution_id'],
            location=data.get('location', '')
        )
        
        db.session.add(campus)
        db.session.commit()
        
        return jsonify({
            'message': 'Campus created successfully',
            'campus': campus.to_dict()
        }), 201
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@bp.route('/campuses', methods=['GET'])
def get_campuses():
    try:
        institution_id = request.args.get('institution_id')
        if institution_id:
            campuses = Campus.query.filter_by(institution_id=institution_id, is_active=True).all()
        else:
            campuses = Campus.query.filter_by(is_active=True).all()
        
        return jsonify({
            'campuses': [campus.to_dict() for campus in campuses]
        }), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# Department Management
@bp.route('/departments', methods=['POST'])
def create_department():
    try:
        data = request.get_json()
        
        required_fields = ['name', 'code', 'campus_id']
        for field in required_fields:
            if not data.get(field):
                return jsonify({'error': f'{field} is required'}), 400
        
        # Verify campus exists
        campus = Campus.query.get(data['campus_id'])
        if not campus:
            return jsonify({'error': 'Campus not found'}), 404
        
        department = Department(
            name=data['name'],
            code=data['code'],
            campus_id=data['campus_id']
        )
        
        db.session.add(department)
        db.session.commit()
        
        return jsonify({
            'message': 'Department created successfully',
            'department': department.to_dict()
        }), 201
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@bp.route('/departments', methods=['GET'])
def get_departments():
    try:
        campus_id = request.args.get('campus_id')
        if campus_id:
            departments = Department.query.filter_by(campus_id=campus_id, is_active=True).all()
        else:
            departments = Department.query.filter_by(is_active=True).all()
        
        return jsonify({
            'departments': [dept.to_dict() for dept in departments]
        }), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# Academic Year Management
@bp.route('/academic-years', methods=['POST'])
def create_academic_year():
    try:
        data = request.get_json()
        
        required_fields = ['year', 'start_date', 'end_date']
        for field in required_fields:
            if not data.get(field):
                return jsonify({'error': f'{field} is required'}), 400
        
        # Check if year exists
        if AcademicYear.query.filter_by(year=data['year']).first():
            return jsonify({'error': 'Academic year already exists'}), 409
        
        academic_year = AcademicYear(
            year=data['year'],
            start_date=datetime.strptime(data['start_date'], '%Y-%m-%d').date(),
            end_date=datetime.strptime(data['end_date'], '%Y-%m-%d').date(),
            is_active=data.get('is_active', False)
        )
        
        # If this is set as active, deactivate others
        if academic_year.is_active:
            AcademicYear.query.update({'is_active': False})
        
        db.session.add(academic_year)
        db.session.commit()
        
        return jsonify({
            'message': 'Academic year created successfully',
            'academic_year': academic_year.to_dict()
        }), 201
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@bp.route('/academic-years', methods=['GET'])
def get_academic_years():
    try:
        academic_years = AcademicYear.query.all()
        return jsonify({
            'academic_years': [ay.to_dict() for ay in academic_years]
        }), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# Program Management
@bp.route('/programs', methods=['POST'])
def create_program():
    try:
        data = request.get_json()
        
        required_fields = ['name', 'code', 'department_id', 'academic_year_id', 'course_type', 'entry_type', 'total_intake']
        for field in required_fields:
            if not data.get(field):
                return jsonify({'error': f'{field} is required'}), 400
        
        # Validate course_type and entry_type
        if data['course_type'] not in ['UG', 'PG']:
            return jsonify({'error': 'Course type must be UG or PG'}), 400
        
        if data['entry_type'] not in ['Regular', 'Lateral']:
            return jsonify({'error': 'Entry type must be Regular or Lateral'}), 400
        
        # Verify department and academic year exist
        department = Department.query.get(data['department_id'])
        if not department:
            return jsonify({'error': 'Department not found'}), 404
            
        academic_year = AcademicYear.query.get(data['academic_year_id'])
        if not academic_year:
            return jsonify({'error': 'Academic year not found'}), 404
        
        program = Program(
            name=data['name'],
            code=data['code'],
            department_id=data['department_id'],
            academic_year_id=data['academic_year_id'],
            course_type=data['course_type'],
            entry_type=data['entry_type'],
            total_intake=data['total_intake']
        )
        
        db.session.add(program)
        db.session.commit()
        
        return jsonify({
            'message': 'Program created successfully',
            'program': program.to_dict()
        }), 201
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@bp.route('/programs', methods=['GET'])
def get_programs():
    try:
        department_id = request.args.get('department_id')
        academic_year_id = request.args.get('academic_year_id')
        
        query = Program.query.filter_by(is_active=True)
        
        if department_id:
            query = query.filter_by(department_id=department_id)
        if academic_year_id:
            query = query.filter_by(academic_year_id=academic_year_id)
        
        programs = query.all()
        
        return jsonify({
            'programs': [program.to_dict() for program in programs]
        }), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@bp.route('/programs/<int:program_id>/quotas', methods=['POST'])
def create_quota(program_id):
    try:
        data = request.get_json()
        
        required_fields = ['quota_type', 'seats_allocated']
        for field in required_fields:
            if not data.get(field):
                return jsonify({'error': f'{field} is required'}), 400
        
        # Verify program exists
        program = Program.query.get(program_id)
        if not program:
            return jsonify({'error': 'Program not found'}), 404
        
        # Validate quota type
        if data['quota_type'] not in ['KCET', 'COMEDK', 'Management']:
            return jsonify({'error': 'Invalid quota type'}), 400
        
        # Check if quota type already exists for this program
        existing_quota = Quota.query.filter_by(
            program_id=program_id, 
            quota_type=data['quota_type']
        ).first()
        if existing_quota:
            return jsonify({'error': 'Quota type already exists for this program'}), 409
        
        # Validate total quota allocation doesn't exceed intake
        existing_quotas = Quota.query.filter_by(program_id=program_id).all()
        total_allocated = sum(q.seats_allocated for q in existing_quotas) + data['seats_allocated']
        
        if total_allocated > program.total_intake:
            return jsonify({
                'error': f'Total quota allocation ({total_allocated}) cannot exceed program intake ({program.total_intake})'
            }), 400
        
        quota = Quota(
            program_id=program_id,
            quota_type=data['quota_type'],
            seats_allocated=data['seats_allocated']
        )
        
        db.session.add(quota)
        db.session.commit()
        
        return jsonify({
            'message': 'Quota created successfully',
            'quota': quota.to_dict()
        }), 201
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@bp.route('/programs/<int:program_id>/quotas', methods=['GET'])
def get_program_quotas(program_id):
    try:
        # Verify program exists
        program = Program.query.get(program_id)
        if not program:
            return jsonify({'error': 'Program not found'}), 404
        
        quotas = Quota.query.filter_by(program_id=program_id, is_active=True).all()
        
        return jsonify({
            'quotas': [quota.to_dict() for quota in quotas],
            'program': program.to_dict()
        }), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500