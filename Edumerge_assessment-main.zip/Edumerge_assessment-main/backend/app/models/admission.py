from app import db
from datetime import datetime

class Quota(db.Model):
    __tablename__ = 'quotas'
    
    id = db.Column(db.Integer, primary_key=True)
    program_id = db.Column(db.Integer, db.ForeignKey('programs.id'), nullable=False)
    quota_type = db.Column(db.Enum('KCET', 'COMEDK', 'Management'), nullable=False)
    seats_allocated = db.Column(db.Integer, nullable=False)
    seats_filled = db.Column(db.Integer, default=0)
    is_active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relationships
    applicants = db.relationship('Applicant', backref='quota', lazy=True)
    
    @property
    def remaining_seats(self):
        return self.seats_allocated - self.seats_filled
    
    def to_dict(self):
        return {
            'id': self.id,
            'program_id': self.program_id,
            'quota_type': self.quota_type,
            'seats_allocated': self.seats_allocated,
            'seats_filled': self.seats_filled,
            'remaining_seats': self.remaining_seats,
            'is_active': self.is_active
        }

class Applicant(db.Model):
    __tablename__ = 'applicants'
    
    id = db.Column(db.Integer, primary_key=True)
    first_name = db.Column(db.String(100), nullable=False)
    last_name = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    phone = db.Column(db.String(15), nullable=False)
    date_of_birth = db.Column(db.Date, nullable=False)
    gender = db.Column(db.Enum('Male', 'Female', 'Other'), nullable=False)
    category = db.Column(db.Enum('GM', 'SC', 'ST', 'OBC', '2A', '2B', '3A', '3B'), nullable=False)
    address = db.Column(db.Text, nullable=False)
    guardian_name = db.Column(db.String(200), nullable=False)
    guardian_phone = db.Column(db.String(15), nullable=False)
    qualifying_exam = db.Column(db.String(100), nullable=False)
    marks_obtained = db.Column(db.Float, nullable=False)
    total_marks = db.Column(db.Float, nullable=False)
    
    # Program and quota selection
    program_id = db.Column(db.Integer, db.ForeignKey('programs.id'), nullable=False)
    quota_id = db.Column(db.Integer, db.ForeignKey('quotas.id'), nullable=True)
    entry_type = db.Column(db.Enum('Regular', 'Lateral'), nullable=False)
    
    # Government allocation details
    allotment_number = db.Column(db.String(50), nullable=True)
    
    # Application status
    application_status = db.Column(db.Enum('Applied', 'Document_Pending', 'Document_Submitted', 'Document_Verified', 'Seat_Allocated', 'Admission_Confirmed'), default='Applied')
    document_status = db.Column(db.Enum('Pending', 'Submitted', 'Verified'), default='Pending')
    fee_status = db.Column(db.Enum('Pending', 'Paid'), default='Pending')
    
    # Admission details
    admission_number = db.Column(db.String(50), unique=True, nullable=True)
    admission_date = db.Column(db.DateTime, nullable=True)
    
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    @property
    def full_name(self):
        return f"{self.first_name} {self.last_name}"
    
    @property
    def percentage(self):
        return (self.marks_obtained / self.total_marks) * 100
    
    def to_dict(self):
        return {
            'id': self.id,
            'first_name': self.first_name,
            'last_name': self.last_name,
            'full_name': self.full_name,
            'email': self.email,
            'phone': self.phone,
            'date_of_birth': self.date_of_birth.isoformat(),
            'gender': self.gender,
            'category': self.category,
            'address': self.address,
            'guardian_name': self.guardian_name,
            'guardian_phone': self.guardian_phone,
            'qualifying_exam': self.qualifying_exam,
            'marks_obtained': self.marks_obtained,
            'total_marks': self.total_marks,
            'percentage': self.percentage,
            'program_id': self.program_id,
            'quota_id': self.quota_id,
            'entry_type': self.entry_type,
            'allotment_number': self.allotment_number,
            'application_status': self.application_status,
            'document_status': self.document_status,
            'fee_status': self.fee_status,
            'admission_number': self.admission_number,
            'admission_date': self.admission_date.isoformat() if self.admission_date else None,
            'created_at': self.created_at.isoformat(),
            'program': self.program.to_dict() if hasattr(self, 'program') else None,
            'quota': self.quota.to_dict() if self.quota else None
        }

class AdmissionLog(db.Model):
    __tablename__ = 'admission_logs'
    
    id = db.Column(db.Integer, primary_key=True)
    applicant_id = db.Column(db.Integer, db.ForeignKey('applicants.id'), nullable=False)
    action = db.Column(db.String(100), nullable=False)
    old_status = db.Column(db.String(50), nullable=True)
    new_status = db.Column(db.String(50), nullable=False)
    performed_by = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    notes = db.Column(db.Text, nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relationships
    applicant = db.relationship('Applicant', backref='logs')
    user = db.relationship('User', backref='performed_actions')
    
    def to_dict(self):
        return {
            'id': self.id,
            'applicant_id': self.applicant_id,
            'action': self.action,
            'old_status': self.old_status,
            'new_status': self.new_status,
            'performed_by': self.performed_by,
            'notes': self.notes,
            'created_at': self.created_at.isoformat()
        }