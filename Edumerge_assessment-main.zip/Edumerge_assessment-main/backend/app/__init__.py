from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask_migrate import Migrate
from flask_cors import CORS
from dotenv import load_dotenv
import os

# Load environment variables
load_dotenv()

# Initialize Flask extensions
db = SQLAlchemy()
migrate = Migrate()

def create_app():
    app = Flask(__name__, static_folder='../frontend/build', static_url_path='/')
    
    # Configuration
    app.config['SECRET_KEY'] = os.getenv('SECRET_KEY', 'dev-secret-key')
    app.config['SQLALCHEMY_DATABASE_URI'] = os.getenv('DATABASE_URL')
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
    
    # Initialize extensions
    db.init_app(app)
    migrate.init_app(app, db)
    CORS(app)

    # Serve frontend index if build exists
    @app.route('/')
    def index():
        return app.send_static_file('index.html')
    
    # Register blueprints
    from app.routes import masters, applicants, admissions, dashboard
    app.register_blueprint(masters.bp)
    app.register_blueprint(applicants.bp)
    app.register_blueprint(admissions.bp)
    app.register_blueprint(dashboard.bp)
    
    return app