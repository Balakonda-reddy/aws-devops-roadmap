from app import create_app, db
from app.models import User, Institution, Campus, Department, Program, AcademicYear
from app.models.admission import Quota, Applicant, AdmissionLog

app = create_app()

@app.cli.command()
def init_db():
    """Initialize the database with tables"""
    db.create_all()
    print("Database tables created successfully!")

@app.cli.command()
def seed_db():
    """Seed the database with initial data"""
    try:
        # Create default admin user
        admin_user = User.query.filter_by(username='admin').first()
        if not admin_user:
            admin_user = User(
                username='admin',
                email='admin@college.edu',
                role='admin'
            )
            admin_user.set_password('admin123')
            db.session.add(admin_user)
        
        # Create admission officer user
        officer_user = User.query.filter_by(username='officer').first()
        if not officer_user:
            officer_user = User(
                username='officer',
                email='officer@college.edu',
                role='admission_officer'
            )
            officer_user.set_password('officer123')
            db.session.add(officer_user)
        
        # Create management user
        mgmt_user = User.query.filter_by(username='management').first()
        if not mgmt_user:
            mgmt_user = User(
                username='management',
                email='management@college.edu',
                role='management'
            )
            mgmt_user.set_password('mgmt123')
            db.session.add(mgmt_user)
        
        db.session.commit()
        print("Default users created successfully!")
        print("Admin - username: admin, password: admin123")
        print("Officer - username: officer, password: officer123")
        print("Management - username: management, password: mgmt123")
        
    except Exception as e:
        db.session.rollback()
        print(f"Error seeding database: {str(e)}")

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)