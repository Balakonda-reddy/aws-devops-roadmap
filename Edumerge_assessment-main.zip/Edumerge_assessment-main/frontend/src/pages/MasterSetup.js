import React, { useState, useEffect } from 'react';
import { Container, Row, Col, Card, Tabs, Tab, Form, Button, Table, Alert } from 'react-bootstrap';
import { toast } from 'react-toastify';
import { mastersAPI } from '../services/api';

const MasterSetup = () => {
  const [activeTab, setActiveTab] = useState('institutions');
  const [institutions, setInstitutions] = useState([]);
  const [campuses, setCampuses] = useState([]);
  const [departments, setDepartments] = useState([]);
  const [programs, setPrograms] = useState([]);
  const [academicYears, setAcademicYears] = useState([]);
  const [quotas, setQuotas] = useState([]);
  
  // Form states
  const [institutionForm, setInstitutionForm] = useState({ name: '', code: '', address: '' });
  const [campusForm, setCampusForm] = useState({ name: '', code: '', institution_id: '', location: '' });
  const [departmentForm, setDepartmentForm] = useState({ name: '', code: '', campus_id: '' });
  const [programForm, setProgramForm] = useState({
    name: '', code: '', department_id: '', academic_year_id: '',
    course_type: 'UG', entry_type: 'Regular', total_intake: ''
  });
  const [academicYearForm, setAcademicYearForm] = useState({
    year: '', start_date: '', end_date: '', is_active: false
  });
  const [quotaForm, setQuotaForm] = useState({
    program_id: '', quota_type: 'KCET', seats_allocated: ''
  });

  useEffect(() => {
    fetchAllData();
  }, []);

  const fetchAllData = async () => {
    try {
      const [instRes, campRes, deptRes, progRes, yearRes] = await Promise.all([
        mastersAPI.getInstitutions(),
        mastersAPI.getCampuses(),
        mastersAPI.getDepartments(),
        mastersAPI.getPrograms(),
        mastersAPI.getAcademicYears()
      ]);
      
      setInstitutions(instRes.data.institutions);
      setCampuses(campRes.data.campuses);
      setDepartments(deptRes.data.departments);
      setPrograms(progRes.data.programs);
      setAcademicYears(yearRes.data.academic_years);
    } catch (error) {
      toast.error('Error fetching data');
    }
  };

  const handleInstitutionSubmit = async (e) => {
    e.preventDefault();
    try {
      await mastersAPI.createInstitution(institutionForm);
      toast.success('Institution created successfully');
      setInstitutionForm({ name: '', code: '', address: '' });
      fetchAllData();
    } catch (error) {
      toast.error(error.response?.data?.error || 'Error creating institution');
    }
  };

  const handleCampusSubmit = async (e) => {
    e.preventDefault();
    try {
      await mastersAPI.createCampus(campusForm);
      toast.success('Campus created successfully');
      setCampusForm({ name: '', code: '', institution_id: '', location: '' });
      fetchAllData();
    } catch (error) {
      toast.error(error.response?.data?.error || 'Error creating campus');
    }
  };

  const handleDepartmentSubmit = async (e) => {
    e.preventDefault();
    try {
      await mastersAPI.createDepartment(departmentForm);
      toast.success('Department created successfully');
      setDepartmentForm({ name: '', code: '', campus_id: '' });
      fetchAllData();
    } catch (error) {
      toast.error(error.response?.data?.error || 'Error creating department');
    }
  };

  const handleProgramSubmit = async (e) => {
    e.preventDefault();
    try {
      await mastersAPI.createProgram(programForm);
      toast.success('Program created successfully');
      setProgramForm({
        name: '', code: '', department_id: '', academic_year_id: '',
        course_type: 'UG', entry_type: 'Regular', total_intake: ''
      });
      fetchAllData();
    } catch (error) {
      toast.error(error.response?.data?.error || 'Error creating program');
    }
  };

  const handleAcademicYearSubmit = async (e) => {
    e.preventDefault();
    try {
      await mastersAPI.createAcademicYear(academicYearForm);
      toast.success('Academic year created successfully');
      setAcademicYearForm({ year: '', start_date: '', end_date: '', is_active: false });
      fetchAllData();
    } catch (error) {
      toast.error(error.response?.data?.error || 'Error creating academic year');
    }
  };

  const handleQuotaSubmit = async (e) => {
    e.preventDefault();
    try {
      const { program_id, ...quotaData } = quotaForm;
      await mastersAPI.createQuota(program_id, quotaData);
      toast.success('Quota created successfully');
      setQuotaForm({ program_id: '', quota_type: 'KCET', seats_allocated: '' });
      fetchQuotas();
    } catch (error) {
      toast.error(error.response?.data?.error || 'Error creating quota');
    }
  };

  const fetchQuotas = async () => {
    if (quotaForm.program_id) {
      try {
        const response = await mastersAPI.getQuotas(quotaForm.program_id);
        setQuotas(response.data.quotas);
      } catch (error) {
        console.error('Error fetching quotas:', error);
      }
    }
  };

  useEffect(() => {
    fetchQuotas();
  }, [quotaForm.program_id]);

  return (
    <Container>
      <h2 className="mb-4">Master Setup</h2>
      
      <Tabs activeKey={activeTab} onSelect={setActiveTab} className="mb-4">
        {/* Institution Tab */}
        <Tab eventKey="institutions" title="Institutions">
          <Row>
            <Col md={6}>
              <Card>
                <Card.Header>Create Institution</Card.Header>
                <Card.Body>
                  <Form onSubmit={handleInstitutionSubmit}>
                    <Form.Group className="mb-3">
                      <Form.Label>Name*</Form.Label>
                      <Form.Control
                        type="text"
                        value={institutionForm.name}
                        onChange={(e) => setInstitutionForm({...institutionForm, name: e.target.value})}
                        required
                      />
                    </Form.Group>
                    <Form.Group className="mb-3">
                      <Form.Label>Code*</Form.Label>
                      <Form.Control
                        type="text"
                        value={institutionForm.code}
                        onChange={(e) => setInstitutionForm({...institutionForm, code: e.target.value})}
                        required
                      />
                    </Form.Group>
                    <Form.Group className="mb-3">
                      <Form.Label>Address</Form.Label>
                      <Form.Control
                        as="textarea"
                        value={institutionForm.address}
                        onChange={(e) => setInstitutionForm({...institutionForm, address: e.target.value})}
                      />
                    </Form.Group>
                    <Button variant="primary" type="submit">Create Institution</Button>
                  </Form>
                </Card.Body>
              </Card>
            </Col>
            <Col md={6}>
              <Card>
                <Card.Header>Existing Institutions</Card.Header>
                <Card.Body>
                  <Table striped bordered hover size="sm">
                    <thead>
                      <tr>
                        <th>Name</th>
                        <th>Code</th>
                      </tr>
                    </thead>
                    <tbody>
                      {institutions.map(inst => (
                        <tr key={inst.id}>
                          <td>{inst.name}</td>
                          <td>{inst.code}</td>
                        </tr>
                      ))}
                    </tbody>
                  </Table>
                </Card.Body>
              </Card>
            </Col>
          </Row>
        </Tab>

        {/* Campus Tab */}
        <Tab eventKey="campuses" title="Campuses">
          <Row>
            <Col md={6}>
              <Card>
                <Card.Header>Create Campus</Card.Header>
                <Card.Body>
                  <Form onSubmit={handleCampusSubmit}>
                    <Form.Group className="mb-3">
                      <Form.Label>Institution*</Form.Label>
                      <Form.Select
                        value={campusForm.institution_id}
                        onChange={(e) => setCampusForm({...campusForm, institution_id: e.target.value})}
                        required
                      >
                        <option value="">Select Institution</option>
                        {institutions.map(inst => (
                          <option key={inst.id} value={inst.id}>{inst.name}</option>
                        ))}
                      </Form.Select>
                    </Form.Group>
                    <Form.Group className="mb-3">
                      <Form.Label>Name*</Form.Label>
                      <Form.Control
                        type="text"
                        value={campusForm.name}
                        onChange={(e) => setCampusForm({...campusForm, name: e.target.value})}
                        required
                      />
                    </Form.Group>
                    <Form.Group className="mb-3">
                      <Form.Label>Code*</Form.Label>
                      <Form.Control
                        type="text"
                        value={campusForm.code}
                        onChange={(e) => setCampusForm({...campusForm, code: e.target.value})}
                        required
                      />
                    </Form.Group>
                    <Form.Group className="mb-3">
                      <Form.Label>Location</Form.Label>
                      <Form.Control
                        type="text"
                        value={campusForm.location}
                        onChange={(e) => setCampusForm({...campusForm, location: e.target.value})}
                      />
                    </Form.Group>
                    <Button variant="primary" type="submit">Create Campus</Button>
                  </Form>
                </Card.Body>
              </Card>
            </Col>
            <Col md={6}>
              <Card>
                <Card.Header>Existing Campuses</Card.Header>
                <Card.Body>
                  <Table striped bordered hover size="sm">
                    <thead>
                      <tr>
                        <th>Name</th>
                        <th>Code</th>
                        <th>Location</th>
                      </tr>
                    </thead>
                    <tbody>
                      {campuses.map(campus => (
                        <tr key={campus.id}>
                          <td>{campus.name}</td>
                          <td>{campus.code}</td>
                          <td>{campus.location}</td>
                        </tr>
                      ))}
                    </tbody>
                  </Table>
                </Card.Body>
              </Card>
            </Col>
          </Row>
        </Tab>

        {/* Academic Years Tab */}
        <Tab eventKey="academic-years" title="Academic Years">
          <Row>
            <Col md={6}>
              <Card>
                <Card.Header>Create Academic Year</Card.Header>
                <Card.Body>
                  <Form onSubmit={handleAcademicYearSubmit}>
                    <Form.Group className="mb-3">
                      <Form.Label>Year*</Form.Label>
                      <Form.Control
                        type="text"
                        placeholder="e.g., 2026-2027"
                        value={academicYearForm.year}
                        onChange={(e) => setAcademicYearForm({...academicYearForm, year: e.target.value})}
                        required
                      />
                    </Form.Group>
                    <Form.Group className="mb-3">
                      <Form.Label>Start Date*</Form.Label>
                      <Form.Control
                        type="date"
                        value={academicYearForm.start_date}
                        onChange={(e) => setAcademicYearForm({...academicYearForm, start_date: e.target.value})}
                        required
                      />
                    </Form.Group>
                    <Form.Group className="mb-3">
                      <Form.Label>End Date*</Form.Label>
                      <Form.Control
                        type="date"
                        value={academicYearForm.end_date}
                        onChange={(e) => setAcademicYearForm({...academicYearForm, end_date: e.target.value})}
                        required
                      />
                    </Form.Group>
                    <Form.Group className="mb-3">
                      <Form.Check
                        type="checkbox"
                        label="Set as Active"
                        checked={academicYearForm.is_active}
                        onChange={(e) => setAcademicYearForm({...academicYearForm, is_active: e.target.checked})}
                      />
                    </Form.Group>
                    <Button variant="primary" type="submit">Create Academic Year</Button>
                  </Form>
                </Card.Body>
              </Card>
            </Col>
            <Col md={6}>
              <Card>
                <Card.Header>Existing Academic Years</Card.Header>
                <Card.Body>
                  <Table striped bordered hover size="sm">
                    <thead>
                      <tr>
                        <th>Year</th>
                        <th>Start Date</th>
                        <th>End Date</th>
                        <th>Active</th>
                      </tr>
                    </thead>
                    <tbody>
                      {academicYears.map(year => (
                        <tr key={year.id}>
                          <td>{year.year}</td>
                          <td>{new Date(year.start_date).toLocaleDateString()}</td>
                          <td>{new Date(year.end_date).toLocaleDateString()}</td>
                          <td>{year.is_active ? 'Yes' : 'No'}</td>
                        </tr>
                      ))}
                    </tbody>
                  </Table>
                </Card.Body>
              </Card>
            </Col>
          </Row>
        </Tab>

        {/* Program Tab */}
        <Tab eventKey="programs" title="Programs">
          <Row>
            <Col md={6}>
              <Card>
                <Card.Header>Create Program</Card.Header>
                <Card.Body>
                  <Form onSubmit={handleProgramSubmit}>
                    <Form.Group className="mb-3">
                      <Form.Label>Department*</Form.Label>
                      <Form.Select
                        value={programForm.department_id}
                        onChange={(e) => setProgramForm({...programForm, department_id: e.target.value})}
                        required
                      >
                        <option value="">Select Department</option>
                        {departments.map(d => <option key={d.id} value={d.id}>{d.name}</option>)}
                      </Form.Select>
                    </Form.Group>

                    <Form.Group className="mb-3">
                      <Form.Label>Academic Year*</Form.Label>
                      <Form.Select
                        value={programForm.academic_year_id}
                        onChange={(e) => setProgramForm({...programForm, academic_year_id: e.target.value})}
                        required
                      >
                        <option value="">Select Academic Year</option>
                        {academicYears.map(y => <option key={y.id} value={y.id}>{y.year}</option>)}
                      </Form.Select>
                    </Form.Group>

                    <Form.Group className="mb-3">
                      <Form.Label>Program Name*</Form.Label>
                      <Form.Control
                        type="text"
                        value={programForm.name}
                        onChange={(e) => setProgramForm({...programForm, name: e.target.value})}
                        required
                      />
                    </Form.Group>

                    <Form.Group className="mb-3">
                      <Form.Label>Code*</Form.Label>
                      <Form.Control
                        type="text"
                        value={programForm.code}
                        onChange={(e) => setProgramForm({...programForm, code: e.target.value})}
                        required
                      />
                    </Form.Group>

                    <Form.Group className="mb-3">
                      <Form.Label>Course Type</Form.Label>
                      <Form.Select
                        value={programForm.course_type}
                        onChange={(e) => setProgramForm({...programForm, course_type: e.target.value})}
                      >
                        <option value="UG">UG</option>
                        <option value="PG">PG</option>
                      </Form.Select>
                    </Form.Group>

                    <Form.Group className="mb-3">
                      <Form.Label>Entry Type</Form.Label>
                      <Form.Select
                        value={programForm.entry_type}
                        onChange={(e) => setProgramForm({...programForm, entry_type: e.target.value})}
                      >
                        <option value="Regular">Regular</option>
                        <option value="Lateral">Lateral</option>
                      </Form.Select>
                    </Form.Group>

                    <Form.Group className="mb-3">
                      <Form.Label>Total Intake</Form.Label>
                      <Form.Control
                        type="number"
                        value={programForm.total_intake}
                        onChange={(e) => setProgramForm({...programForm, total_intake: e.target.value})}
                      />
                    </Form.Group>

                    <Button variant="primary" type="submit">Create Program</Button>
                  </Form>
                </Card.Body>
              </Card>
            </Col>

            <Col md={6}>
              <Card>
                <Card.Header>Existing Programs</Card.Header>
                <Card.Body>
                  <Table striped bordered hover size="sm">
                    <thead>
                      <tr>
                        <th>Name</th>
                        <th>Code</th>
                        <th>Department</th>
                        <th>Year</th>
                        <th>Intake</th>
                      </tr>
                    </thead>
                    <tbody>
                      {programs.map(p => (
                        <tr key={p.id}>
                          <td>{p.name}</td>
                          <td>{p.code}</td>
                          <td>{
                            p.department_name ||
                            (p.department && (p.department.name || String(p.department))) ||
                            ''
                          }</td>
                          <td>{
                            (p.academic_year && (p.academic_year.year || String(p.academic_year))) ||
                            p.academic_year_id ||
                            ''
                          }</td>
                          <td>{p.total_intake}</td>
                        </tr>
                      ))}
                    </tbody>
                  </Table>
                </Card.Body>
              </Card>
            </Col>
          </Row>
        </Tab>
      </Tabs>
    </Container>
  );
};

export default MasterSetup;