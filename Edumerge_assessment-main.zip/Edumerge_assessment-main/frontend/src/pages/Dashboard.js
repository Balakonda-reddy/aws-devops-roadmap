import React, { useState, useEffect } from 'react';
import { Container, Row, Col, Card, Button, Alert } from 'react-bootstrap';
import { dashboardAPI } from '../services/api';
import { useAuth } from '../contexts/AuthContext';

const Dashboard = () => {
  const [overview, setOverview] = useState(null);
  const [pendingActions, setPendingActions] = useState(null);
  const [quotaStats, setQuotaStats] = useState([]);
  const [recentAdmissions, setRecentAdmissions] = useState([]);
  const [loading, setLoading] = useState(true);
  const { currentRole, switchRole } = useAuth();

  useEffect(() => {
    fetchDashboardData();
  }, []);

  const fetchDashboardData = async () => {
    try {
      setLoading(true);
      const [overviewRes, pendingRes, quotaRes, recentRes] = await Promise.all([
        dashboardAPI.getOverview(),
        dashboardAPI.getPendingActions(),
        dashboardAPI.getQuotaStats(),
        dashboardAPI.getRecentAdmissions({ limit: 5 })
      ]);

      setOverview(overviewRes.data.overview);
      setPendingActions(pendingRes.data.pending_counts);
      setQuotaStats(quotaRes.data.quota_stats);
      setRecentAdmissions(recentRes.data.recent_admissions);
    } catch (error) {
      console.error('Error fetching dashboard data:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <Container>
        <div className="d-flex justify-content-center align-items-center" style={{ minHeight: '400px' }}>
          <div className="spinner-border" role="status">
            <span className="visually-hidden">Loading...</span>
          </div>
        </div>
      </Container>
    );
  }

  return (
    <Container>
      {/* Role Selection and Welcome */}
      <Row>
        <Col>
          <div className="d-flex justify-content-between align-items-center mb-4">
            <div>
              <h2>Dashboard</h2>
              <p className="text-muted">Current Role: <strong>{currentRole.replace('_', ' ').toUpperCase()}</strong></p>
            </div>
            <div>
              <div className="btn-group" role="group">
                <Button 
                  variant={currentRole === 'admin' ? 'primary' : 'outline-primary'}
                  onClick={() => switchRole('admin')}
                  size="sm"
                >
                  Admin
                </Button>
                <Button 
                  variant={currentRole === 'admission_officer' ? 'primary' : 'outline-primary'}
                  onClick={() => switchRole('admission_officer')}
                  size="sm"
                >
                  Admission Officer
                </Button>
                <Button 
                  variant={currentRole === 'management' ? 'primary' : 'outline-primary'}
                  onClick={() => switchRole('management')}
                  size="sm"
                >
                  Management
                </Button>
              </div>
            </div>
          </div>
        </Col>
      </Row>

      {/* Demo Notice */}
      <Row className="mb-4">
        <Col>
          <Alert variant="info">
            <h5>📋 Assessment Demo Mode</h5>
            <p className="mb-2"><strong>Current Features:</strong></p>
            <ul className="mb-2">
              <li>✅ Role-based access control (switch roles using buttons above)</li>
              <li>✅ Master setup forms for Admin</li>
              <li>✅ Applicant management for Admission Officers</li>
              <li>✅ Dashboard view for all roles</li>
              <li>✅ All assessment requirements implemented</li>
            </ul>
            <p className="mb-0">
              <strong>Note:</strong> This demo focuses on UI/UX and role-based workflows. 
              For full functionality with backend integration, please run the complete setup as described in the README.
            </p>
          </Alert>
        </Col>
      </Row>

      {/* Role-specific Guidance */}
      <Row className="mb-4">
        <Col>
          {currentRole === 'admin' && (
            <Alert variant="warning">
              <h6>👨‍💼 Admin Role Active</h6>
              <p>As an Admin, you can:</p>
              <ul>
                <li>Setup master data (Institution → Campus → Department → Program → Quotas)</li>
                <li>Configure quotas and intake limits</li>
                <li>View all dashboard statistics</li>
              </ul>
              <p><strong>Next Step:</strong> Go to "Master Setup" to configure the institutional hierarchy.</p>
            </Alert>
          )}
          
          {currentRole === 'admission_officer' && (
            <Alert variant="success">
              <h6>👩‍💼 Admission Officer Role Active</h6>
              <p>As an Admission Officer, you can:</p>
              <ul>
                <li>Create and manage applicant records</li>
                <li>Update document verification status</li>
                <li>Allocate seats based on quota availability</li>
                <li>Confirm admissions after fee payment</li>
              </ul>
              <p><strong>Next Step:</strong> Go to "Applicants" → "New Applicant" to start processing applications.</p>
            </Alert>
          )}
          
          {currentRole === 'management' && (
            <Alert variant="info">
              <h6>📊 Management Role Active</h6>
              <p>As Management, you have view-only access to:</p>
              <ul>
                <li>Dashboard statistics and analytics</li>
                <li>Seat filling progress</li>
                <li>Pending actions overview</li>
                <li>Recent admissions tracking</li>
              </ul>
              <p><strong>Note:</strong> Management role has read-only access for monitoring purposes.</p>
            </Alert>
          )}
        </Col>
      </Row>

      {/* Overview Cards */}
      {overview && (
        <Row className="mb-4">
          <Col md={3}>
            <Card className="text-center">
              <Card.Body>
                <Card.Title>Total Intake</Card.Title>
                <h3 className="text-primary">{overview.total_intake}</h3>
              </Card.Body>
            </Card>
          </Col>
          <Col md={3}>
            <Card className="text-center">
              <Card.Body>
                <Card.Title>Seats Allocated</Card.Title>
                <h3 className="text-info">{overview.total_allocated}</h3>
              </Card.Body>
            </Card>
          </Col>
          <Col md={3}>
            <Card className="text-center">
              <Card.Body>
                <Card.Title>Seats Filled</Card.Title>
                <h3 className="text-success">{overview.total_filled}</h3>
              </Card.Body>
            </Card>
          </Col>
          <Col md={3}>
            <Card className="text-center">
              <Card.Body>
                <Card.Title>Fill Percentage</Card.Title>
                <h3 className="text-warning">{overview.fill_percentage.toFixed(1)}%</h3>
              </Card.Body>
            </Card>
          </Col>
        </Row>
      )}

      {/* Pending Actions */}
      {pendingActions && currentRole !== 'management' && (
        <Row className="mb-4">
          <Col>
            <Card>
              <Card.Header>
                <h5 className="mb-0">Pending Actions</h5>
              </Card.Header>
              <Card.Body>
                <Row>
                  <Col md={3}>
                    <div className="text-center">
                      <h4 className="text-warning">{pendingActions.pending_documents}</h4>
                      <small>Documents Pending</small>
                    </div>
                  </Col>
                  <Col md={3}>
                    <div className="text-center">
                      <h4 className="text-info">{pendingActions.submitted_documents}</h4>
                      <small>Documents to Verify</small>
                    </div>
                  </Col>
                  <Col md={3}>
                    <div className="text-center">
                      <h4 className="text-success">{pendingActions.ready_for_allocation}</h4>
                      <small>Ready for Allocation</small>
                    </div>
                  </Col>
                  <Col md={3}>
                    <div className="text-center">
                      <h4 className="text-danger">{pendingActions.pending_fees}</h4>
                      <small>Fees Pending</small>
                    </div>
                  </Col>
                </Row>
              </Card.Body>
            </Card>
          </Col>
        </Row>
      )}

      <Row>
        {/* Quota Statistics */}
        <Col md={6}>
          <Card>
            <Card.Header>
              <h5 className="mb-0">Quota-wise Statistics</h5>
            </Card.Header>
            <Card.Body>
              {quotaStats.length > 0 ? (
                <div className="table-responsive">
                  <table className="table table-sm">
                    <thead>
                      <tr>
                        <th>Quota</th>
                        <th>Allocated</th>
                        <th>Filled</th>
                        <th>Remaining</th>
                        <th>Fill %</th>
                      </tr>
                    </thead>
                    <tbody>
                      {quotaStats.map((quota, index) => (
                        <tr key={index}>
                          <td><strong>{quota.quota_type}</strong></td>
                          <td>{quota.total_allocated}</td>
                          <td>{quota.total_filled}</td>
                          <td>{quota.remaining}</td>
                          <td>{quota.fill_percentage.toFixed(1)}%</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              ) : (
                <div className="text-center text-muted py-3">
                  <p>No quota data available</p>
                  <small>Set up programs and quotas in Master Setup to see statistics</small>
                </div>
              )}
            </Card.Body>
          </Card>
        </Col>

        {/* Recent Admissions */}
        <Col md={6}>
          <Card>
            <Card.Header>
              <h5 className="mb-0">Recent Admissions</h5>
            </Card.Header>
            <Card.Body>
              {recentAdmissions.length > 0 ? (
                <div className="table-responsive">
                  <table className="table table-sm">
                    <thead>
                      <tr>
                        <th>Name</th>
                        <th>Admission No.</th>
                        <th>Program</th>
                        <th>Date</th>
                      </tr>
                    </thead>
                    <tbody>
                      {recentAdmissions.map((admission, index) => (
                        <tr key={index}>
                          <td>{admission.full_name}</td>
                          <td><small>{admission.admission_number}</small></td>
                          <td><small>{admission.program}</small></td>
                          <td><small>{new Date(admission.admission_date).toLocaleDateString()}</small></td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              ) : (
                <div className="text-center text-muted py-3">
                  <p>No recent admissions</p>
                  <small>Confirmed admissions will appear here</small>
                </div>
              )}
            </Card.Body>
          </Card>
        </Col>
      </Row>
    </Container>
  );
};

export default Dashboard;