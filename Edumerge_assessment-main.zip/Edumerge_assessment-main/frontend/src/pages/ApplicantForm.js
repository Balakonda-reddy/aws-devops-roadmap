import React, { useState, useEffect } from 'react';
import { Container, Row, Col, Card, Form, Button, Alert } from 'react-bootstrap';
import { useNavigate, useParams } from 'react-router-dom';
import { toast } from 'react-toastify';
import { applicantsAPI, mastersAPI } from '../services/api';

const ApplicantForm = () => {
  const [formData, setFormData] = useState({
    first_name: '',
    last_name: '',
    email: '',
    phone: '',
    date_of_birth: '',
    gender: '',
    category: '',
    address: '',
    guardian_name: '',
    guardian_phone: '',
    qualifying_exam: '',
    marks_obtained: '',
    total_marks: '',
    program_id: '',
    entry_type: '',
    allotment_number: ''
  });
  const [programs, setPrograms] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const navigate = useNavigate();
  const { id } = useParams();
  const isEdit = !!id;

  useEffect(() => {
    fetchPrograms();
    if (isEdit) {
      fetchApplicant();
    }
  }, [id]);

  const fetchPrograms = async () => {
    try {
      const response = await mastersAPI.getPrograms();
      setPrograms(response.data.programs);
    } catch (error) {
      toast.error('Error fetching programs');
    }
  };

  const fetchApplicant = async () => {
    try {
      const response = await applicantsAPI.getById(id);
      const applicant = response.data.applicant;
      setFormData({
        first_name: applicant.first_name,
        last_name: applicant.last_name,
        email: applicant.email,
        phone: applicant.phone,
        date_of_birth: applicant.date_of_birth,
        gender: applicant.gender,
        category: applicant.category,
        address: applicant.address,
        guardian_name: applicant.guardian_name,
        guardian_phone: applicant.guardian_phone,
        qualifying_exam: applicant.qualifying_exam,
        marks_obtained: applicant.marks_obtained.toString(),
        total_marks: applicant.total_marks.toString(),
        program_id: applicant.program_id.toString(),
        entry_type: applicant.entry_type,
        allotment_number: applicant.allotment_number || ''
      });
    } catch (error) {
      toast.error('Error fetching applicant data');
      navigate('/applicants');
    }
  };

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      const submitData = {
        ...formData,
        marks_obtained: parseFloat(formData.marks_obtained),
        total_marks: parseFloat(formData.total_marks),
        program_id: parseInt(formData.program_id)
      };

      if (isEdit) {
        await applicantsAPI.update(id, submitData);
        toast.success('Applicant updated successfully');
      } else {
        await applicantsAPI.create(submitData);
        toast.success('Applicant created successfully');
      }
      
      navigate('/applicants');
    } catch (error) {
      setError(error.response?.data?.error || 'Error saving applicant');
    } finally {
      setLoading(false);
    }
  };

  return (
    <Container>
      <Row>
        <Col>
          <h2 className="mb-4">{isEdit ? 'Edit' : 'New'} Applicant</h2>
        </Col>
      </Row>

      <Row>
        <Col md={8}>
          <Card>
            <Card.Body>
              {error && <Alert variant="danger">{error}</Alert>}
              
              <Form onSubmit={handleSubmit}>
                <Row>
                  <Col md={6}>
                    <Form.Group className="mb-3">
                      <Form.Label>First Name*</Form.Label>
                      <Form.Control
                        type="text"
                        name="first_name"
                        value={formData.first_name}
                        onChange={handleChange}
                        required
                      />
                    </Form.Group>
                  </Col>
                  <Col md={6}>
                    <Form.Group className="mb-3">
                      <Form.Label>Last Name*</Form.Label>
                      <Form.Control
                        type="text"
                        name="last_name"
                        value={formData.last_name}
                        onChange={handleChange}
                        required
                      />
                    </Form.Group>
                  </Col>
                </Row>

                <Row>
                  <Col md={6}>
                    <Form.Group className="mb-3">
                      <Form.Label>Email*</Form.Label>
                      <Form.Control
                        type="email"
                        name="email"
                        value={formData.email}
                        onChange={handleChange}
                        required
                        disabled={isEdit}
                      />
                    </Form.Group>
                  </Col>
                  <Col md={6}>
                    <Form.Group className="mb-3">
                      <Form.Label>Phone*</Form.Label>
                      <Form.Control
                        type="tel"
                        name="phone"
                        value={formData.phone}
                        onChange={handleChange}
                        required
                      />
                    </Form.Group>
                  </Col>
                </Row>

                <Row>
                  <Col md={4}>
                    <Form.Group className="mb-3">
                      <Form.Label>Date of Birth*</Form.Label>
                      <Form.Control
                        type="date"
                        name="date_of_birth"
                        value={formData.date_of_birth}
                        onChange={handleChange}
                        required
                        disabled={isEdit}
                      />
                    </Form.Group>
                  </Col>
                  <Col md={4}>
                    <Form.Group className="mb-3">
                      <Form.Label>Gender*</Form.Label>
                      <Form.Select
                        name="gender"
                        value={formData.gender}
                        onChange={handleChange}
                        required
                        disabled={isEdit}
                      >
                        <option value="">Select Gender</option>
                        <option value="Male">Male</option>
                        <option value="Female">Female</option>
                        <option value="Other">Other</option>
                      </Form.Select>
                    </Form.Group>
                  </Col>
                  <Col md={4}>
                    <Form.Group className="mb-3">
                      <Form.Label>Category*</Form.Label>
                      <Form.Select
                        name="category"
                        value={formData.category}
                        onChange={handleChange}
                        required
                        disabled={isEdit}
                      >
                        <option value="">Select Category</option>
                        <option value="GM">General (GM)</option>
                        <option value="SC">Scheduled Caste (SC)</option>
                        <option value="ST">Scheduled Tribe (ST)</option>
                        <option value="OBC">Other Backward Caste (OBC)</option>
                        <option value="2A">Category 2A</option>
                        <option value="2B">Category 2B</option>
                        <option value="3A">Category 3A</option>
                        <option value="3B">Category 3B</option>
                      </Form.Select>
                    </Form.Group>
                  </Col>
                </Row>

                <Form.Group className="mb-3">
                  <Form.Label>Address*</Form.Label>
                  <Form.Control
                    as="textarea"
                    rows={3}
                    name="address"
                    value={formData.address}
                    onChange={handleChange}
                    required
                  />
                </Form.Group>

                <Row>
                  <Col md={6}>
                    <Form.Group className="mb-3">
                      <Form.Label>Guardian Name*</Form.Label>
                      <Form.Control
                        type="text"
                        name="guardian_name"
                        value={formData.guardian_name}
                        onChange={handleChange}
                        required
                      />
                    </Form.Group>
                  </Col>
                  <Col md={6}>
                    <Form.Group className="mb-3">
                      <Form.Label>Guardian Phone*</Form.Label>
                      <Form.Control
                        type="tel"
                        name="guardian_phone"
                        value={formData.guardian_phone}
                        onChange={handleChange}
                        required
                      />
                    </Form.Group>
                  </Col>
                </Row>

                <Row>
                  <Col md={4}>
                    <Form.Group className="mb-3">
                      <Form.Label>Qualifying Exam*</Form.Label>
                      <Form.Control
                        type="text"
                        name="qualifying_exam"
                        value={formData.qualifying_exam}
                        onChange={handleChange}
                        required
                        disabled={isEdit}
                      />
                    </Form.Group>
                  </Col>
                  <Col md={4}>
                    <Form.Group className="mb-3">
                      <Form.Label>Marks Obtained*</Form.Label>
                      <Form.Control
                        type="number"
                        step="0.01"
                        name="marks_obtained"
                        value={formData.marks_obtained}
                        onChange={handleChange}
                        required
                        disabled={isEdit}
                      />
                    </Form.Group>
                  </Col>
                  <Col md={4}>
                    <Form.Group className="mb-3">
                      <Form.Label>Total Marks*</Form.Label>
                      <Form.Control
                        type="number"
                        step="0.01"
                        name="total_marks"
                        value={formData.total_marks}
                        onChange={handleChange}
                        required
                        disabled={isEdit}
                      />
                    </Form.Group>
                  </Col>
                </Row>

                <Row>
                  <Col md={6}>
                    <Form.Group className="mb-3">
                      <Form.Label>Program*</Form.Label>
                      <Form.Select
                        name="program_id"
                        value={formData.program_id}
                        onChange={handleChange}
                        required
                        disabled={isEdit}
                      >
                        <option value="">Select Program</option>
                        {programs.map(program => (
                          <option key={program.id} value={program.id}>
                            {program.name} ({program.code}) - {program.course_type}
                          </option>
                        ))}
                      </Form.Select>
                    </Form.Group>
                  </Col>
                  <Col md={6}>
                    <Form.Group className="mb-3">
                      <Form.Label>Entry Type*</Form.Label>
                      <Form.Select
                        name="entry_type"
                        value={formData.entry_type}
                        onChange={handleChange}
                        required
                        disabled={isEdit}
                      >
                        <option value="">Select Entry Type</option>
                        <option value="Regular">Regular</option>
                        <option value="Lateral">Lateral Entry</option>
                      </Form.Select>
                    </Form.Group>
                  </Col>
                </Row>

                <Form.Group className="mb-3">
                  <Form.Label>Allotment Number (for KCET/COMEDK)</Form.Label>
                  <Form.Control
                    type="text"
                    name="allotment_number"
                    value={formData.allotment_number}
                    onChange={handleChange}
                    placeholder="Enter allotment number if applicable"
                  />
                </Form.Group>

                <div className="d-flex justify-content-between">
                  <Button
                    variant="secondary"
                    onClick={() => navigate('/applicants')}
                  >
                    Cancel
                  </Button>
                  <Button
                    variant="primary"
                    type="submit"
                    disabled={loading}
                  >
                    {loading ? 'Saving...' : (isEdit ? 'Update' : 'Create')} Applicant
                  </Button>
                </div>
              </Form>
            </Card.Body>
          </Card>
        </Col>

        <Col md={4}>
          <Card>
            <Card.Header>
              <h6>Form Guidelines</h6>
            </Card.Header>
            <Card.Body>
              <small className="text-muted">
                <ul>
                  <li>All fields marked with * are required</li>
                  <li>Email must be unique for each applicant</li>
                  <li>Allotment number is required for KCET/COMEDK quota allocation</li>
                  <li>Once saved, some fields cannot be edited (marked as disabled)</li>
                  <li>Academic information like marks and program cannot be changed after creation</li>
                </ul>
              </small>
            </Card.Body>
          </Card>
        </Col>
      </Row>
    </Container>
  );
};

export default ApplicantForm;