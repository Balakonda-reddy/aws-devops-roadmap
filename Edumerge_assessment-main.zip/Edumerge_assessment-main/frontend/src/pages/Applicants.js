import React, { useState, useEffect } from 'react';
import { Container, Row, Col, Card, Table, Button, Form, Badge } from 'react-bootstrap';
import { useNavigate } from 'react-router-dom';
import { toast } from 'react-toastify';
import { applicantsAPI } from '../services/api';
import { useAuth } from '../contexts/AuthContext';

const Applicants = () => {
  const [applicants, setApplicants] = useState([]);
  const [loading, setLoading] = useState(true);
  const [pagination, setPagination] = useState({});
  const [filters, setFilters] = useState({
    page: 1,
    per_page: 10,
    status: '',
    search: ''
  });
  
  const navigate = useNavigate();
  const { isAdmissionOfficer } = useAuth();

  useEffect(() => {
    fetchApplicants();
  }, [filters]);

  const fetchApplicants = async () => {
    try {
      setLoading(true);
      const response = await applicantsAPI.getAll(filters);
      setApplicants(response.data.applicants);
      setPagination(response.data.pagination);
    } catch (error) {
      toast.error('Error fetching applicants');
    } finally {
      setLoading(false);
    }
  };

  const handleFilterChange = (key, value) => {
    setFilters({
      ...filters,
      [key]: value,
      page: 1 // Reset to first page when filtering
    });
  };

  const getStatusBadge = (status) => {
    const statusConfig = {
      'Applied': 'secondary',
      'Document_Pending': 'warning',
      'Document_Submitted': 'info',
      'Document_Verified': 'primary',
      'Seat_Allocated': 'success',
      'Admission_Confirmed': 'success'
    };
    
    return (
      <Badge bg={statusConfig[status] || 'secondary'}>
        {status.replace('_', ' ')}
      </Badge>
    );
  };

  const handleViewApplicant = (id) => {
    navigate(`/applicants/${id}`);
  };

  const handleEditApplicant = (id) => {
    navigate(`/applicants/${id}/edit`);
  };

  if (loading) {
    return (
      <Container>
        <div className="d-flex justify-content-center align-items-center" style={{ minHeight: '400px' }}>
          <div className="spinner-border" role="status">
            <span className="visually-hidden">Loading...</span>
          </div>
        </div>
      </Container>
    );
  }

  return (
    <Container>
      <Row>
        <Col>
          <div className="d-flex justify-content-between align-items-center mb-4">
            <h2>Applicants</h2>
            {isAdmissionOfficer && (
              <Button 
                variant="primary" 
                onClick={() => navigate('/applicants/new')}
              >
                New Applicant
              </Button>
            )}
          </div>
        </Col>
      </Row>

      {/* Filters */}
      <Row className="mb-4">
        <Col md={4}>
          <Form.Group>
            <Form.Label>Search</Form.Label>
            <Form.Control
              type="text"
              placeholder="Search by name, email, phone..."
              value={filters.search}
              onChange={(e) => handleFilterChange('search', e.target.value)}
            />
          </Form.Group>
        </Col>
        <Col md={3}>
          <Form.Group>
            <Form.Label>Status</Form.Label>
            <Form.Select
              value={filters.status}
              onChange={(e) => handleFilterChange('status', e.target.value)}
            >
              <option value="">All Status</option>
              <option value="Applied">Applied</option>
              <option value="Document_Pending">Document Pending</option>
              <option value="Document_Submitted">Document Submitted</option>
              <option value="Document_Verified">Document Verified</option>
              <option value="Seat_Allocated">Seat Allocated</option>
              <option value="Admission_Confirmed">Admission Confirmed</option>
            </Form.Select>
          </Form.Group>
        </Col>
        <Col md={2}>
          <Form.Group>
            <Form.Label>Per Page</Form.Label>
            <Form.Select
              value={filters.per_page}
              onChange={(e) => handleFilterChange('per_page', parseInt(e.target.value))}
            >
              <option value={10}>10</option>
              <option value={25}>25</option>
              <option value={50}>50</option>
            </Form.Select>
          </Form.Group>
        </Col>
      </Row>

      {/* Applicants Table */}
      <Row>
        <Col>
          <Card>
            <Card.Body>
              <div className="table-responsive">
                <Table striped bordered hover>
                  <thead>
                    <tr>
                      <th>Name</th>
                      <th>Email</th>
                      <th>Phone</th>
                      <th>Program</th>
                      <th>Status</th>
                      <th>Document Status</th>
                      <th>Fee Status</th>
                      <th>Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {applicants.length > 0 ? (
                      applicants.map((applicant) => (
                        <tr key={applicant.id}>
                          <td>{applicant.full_name}</td>
                          <td>{applicant.email}</td>
                          <td>{applicant.phone}</td>
                          <td>{applicant.program?.name || 'N/A'}</td>
                          <td>{getStatusBadge(applicant.application_status)}</td>
                          <td>
                            <Badge bg={applicant.document_status === 'Verified' ? 'success' : 'warning'}>
                              {applicant.document_status}
                            </Badge>
                          </td>
                          <td>
                            <Badge bg={applicant.fee_status === 'Paid' ? 'success' : 'warning'}>
                              {applicant.fee_status}
                            </Badge>
                          </td>
                          <td>
                            <Button
                              variant="outline-primary"
                              size="sm"
                              className="me-1"
                              onClick={() => handleViewApplicant(applicant.id)}
                            >
                              View
                            </Button>
                            {isAdmissionOfficer && (
                              <Button
                                variant="outline-secondary"
                                size="sm"
                                onClick={() => handleEditApplicant(applicant.id)}
                              >
                                Edit
                              </Button>
                            )}
                          </td>
                        </tr>
                      ))
                    ) : (
                      <tr>
                        <td colSpan="8" className="text-center">
                          No applicants found
                        </td>
                      </tr>
                    )}
                  </tbody>
                </Table>
              </div>

              {/* Pagination */}
              {pagination.pages > 1 && (
                <div className="d-flex justify-content-between align-items-center mt-3">
                  <div>
                    Showing {((pagination.page - 1) * pagination.per_page) + 1} to {Math.min(pagination.page * pagination.per_page, pagination.total)} of {pagination.total} entries
                  </div>
                  <div>
                    <Button
                      variant="outline-secondary"
                      size="sm"
                      disabled={!pagination.has_prev}
                      onClick={() => handleFilterChange('page', pagination.page - 1)}
                    >
                      Previous
                    </Button>
                    <span className="mx-2">Page {pagination.page} of {pagination.pages}</span>
                    <Button
                      variant="outline-secondary"
                      size="sm"
                      disabled={!pagination.has_next}
                      onClick={() => handleFilterChange('page', pagination.page + 1)}
                    >
                      Next
                    </Button>
                  </div>
                </div>
              )}
            </Card.Body>
          </Card>
        </Col>
      </Row>
    </Container>
  );
};

export default Applicants;