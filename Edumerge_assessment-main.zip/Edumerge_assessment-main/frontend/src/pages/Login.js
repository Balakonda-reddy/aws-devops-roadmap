// Login component removed - using role selector instead
// This file is kept for backward compatibility but not used in the simplified version

import React from 'react';

const Login = () => {
  return null;
};

export default Login;