import React from 'react';
import { Navbar as BSNavbar, Nav, NavDropdown, Container } from 'react-bootstrap';
import { LinkContainer } from 'react-router-bootstrap';
import { useAuth } from '../contexts/AuthContext';

const Navbar = () => {
  const { user, currentRole, switchRole, isAdmin, isAdmissionOfficer } = useAuth();

  const handleRoleChange = (role) => {
    switchRole(role);
    window.location.reload(); // Refresh to apply role changes
  };

  return (
    <BSNavbar bg="dark" variant="dark" expand="lg" className="mb-4">
      <Container>
        <LinkContainer to="/">
          <BSNavbar.Brand>Admission Management System</BSNavbar.Brand>
        </LinkContainer>
        
        <BSNavbar.Toggle aria-controls="basic-navbar-nav" />
        <BSNavbar.Collapse id="basic-navbar-nav">
          <Nav className="me-auto">
            <LinkContainer to="/">
              <Nav.Link>Dashboard</Nav.Link>
            </LinkContainer>
            
            {isAdmin && (
              <LinkContainer to="/master-setup">
                <Nav.Link>Master Setup</Nav.Link>
              </LinkContainer>
            )}
            
            {isAdmissionOfficer && (
              <NavDropdown title="Applicants" id="applicants-dropdown">
                <LinkContainer to="/applicants">
                  <NavDropdown.Item>View Applicants</NavDropdown.Item>
                </LinkContainer>
                <LinkContainer to="/applicants/new">
                  <NavDropdown.Item>New Applicant</NavDropdown.Item>
                </LinkContainer>
              </NavDropdown>
            )}
            
            {isAdmissionOfficer && (
              <NavDropdown title="Admissions" id="admissions-dropdown">
                <LinkContainer to="/seat-allocation">
                  <NavDropdown.Item>Seat Allocation</NavDropdown.Item>
                </LinkContainer>
                <LinkContainer to="/admission-confirmation">
                  <NavDropdown.Item>Admission Confirmation</NavDropdown.Item>
                </LinkContainer>
              </NavDropdown>
            )}
          </Nav>
          
          <Nav>
            <NavDropdown title={`Current Role: ${currentRole.replace('_', ' ').toUpperCase()}`} id="role-selector">
              <NavDropdown.Item 
                onClick={() => handleRoleChange('admin')}
                active={currentRole === 'admin'}
              >
                Admin
              </NavDropdown.Item>
              <NavDropdown.Item 
                onClick={() => handleRoleChange('admission_officer')}
                active={currentRole === 'admission_officer'}
              >
                Admission Officer
              </NavDropdown.Item>
              <NavDropdown.Item 
                onClick={() => handleRoleChange('management')}
                active={currentRole === 'management'}
              >
                Management (View Only)
              </NavDropdown.Item>
            </NavDropdown>
          </Nav>
        </BSNavbar.Collapse>
      </Container>
    </BSNavbar>
  );
};

export default Navbar;