import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { ToastContainer } from 'react-toastify';

import { AuthProvider, useAuth } from './contexts/AuthContext';

// Components
import Navbar from './components/Navbar';
import Dashboard from './pages/Dashboard';
import MasterSetup from './pages/MasterSetup';
import Applicants from './pages/Applicants';
import ApplicantForm from './pages/ApplicantForm';
import SeatAllocation from './pages/SeatAllocation';
import AdmissionConfirmation from './pages/AdmissionConfirmation';

// Protected Route component
const ProtectedRoute = ({ children, requiredRole = null }) => {
  const { currentRole } = useAuth();

  if (requiredRole && currentRole !== requiredRole && currentRole !== 'admin') {
    return (
      <div className="container mt-4">
        <div className="alert alert-danger">
          <h5>Access Denied</h5>
          <p>You don't have permission to view this page.</p>
          <p>Current Role: <strong>{currentRole.replace('_', ' ').toUpperCase()}</strong></p>
          <p>Required Role: <strong>{requiredRole.replace('_', ' ').toUpperCase()}</strong></p>
          <p>Please switch to the appropriate role using the dropdown in the navigation bar.</p>
        </div>
      </div>
    );
  }

  return children;
};

const AppContent = () => {
  return (
    <div className="App">
      <Navbar />
      
      <Routes>
        <Route path="/" element={<Dashboard />} />
        
        <Route 
          path="/master-setup" 
          element={
            <ProtectedRoute requiredRole="admin">
              <MasterSetup />
            </ProtectedRoute>
          } 
        />
        
        <Route path="/applicants" element={<Applicants />} />
        
        <Route 
          path="/applicants/new" 
          element={
            <ProtectedRoute>
              <ApplicantForm />
            </ProtectedRoute>
          } 
        />
        
        <Route 
          path="/applicants/:id/edit" 
          element={
            <ProtectedRoute>
              <ApplicantForm />
            </ProtectedRoute>
          } 
        />
        
        <Route 
          path="/seat-allocation" 
          element={
            <ProtectedRoute>
              <SeatAllocation />
            </ProtectedRoute>
          } 
        />
        
        <Route 
          path="/admission-confirmation" 
          element={
            <ProtectedRoute>
              <AdmissionConfirmation />
            </ProtectedRoute>
          } 
        />
        
        {/* Redirect unknown routes */}
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
      
      <ToastContainer
        position="top-right"
        autoClose={3000}
        hideProgressBar={false}
        newestOnTop={false}
        closeOnClick
        rtl={false}
        pauseOnFocusLoss
        draggable
        pauseOnHover
      />
    </div>
  );
};

function App() {
  return (
    <AuthProvider>
      <Router>
        <AppContent />
      </Router>
    </AuthProvider>
  );
}

export default App;