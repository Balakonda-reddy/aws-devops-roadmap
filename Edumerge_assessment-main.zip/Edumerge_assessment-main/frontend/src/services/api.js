import axios from 'axios';

const API_BASE_URL = process.env.REACT_APP_API_URL || 'http://localhost:5000/api';

// Create axios instance
const api = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Simple mock data for demonstration (since we removed authentication)
const mockResponses = {
  '/masters/institutions': { institutions: [] },
  '/masters/campuses': { campuses: [] },
  '/masters/departments': { departments: [] },
  '/masters/programs': { programs: [] },
  '/masters/academic-years': { academic_years: [] },
  '/applicants': { applicants: [], pagination: { page: 1, per_page: 10, total: 0, pages: 0 } },
  '/dashboard/overview': { 
    overview: { 
      total_intake: 0, 
      total_allocated: 0, 
      total_filled: 0, 
      fill_percentage: 0 
    },
    program_stats: [],
    application_stats: [],
    document_stats: [],
    fee_stats: []
  },
  '/dashboard/pending-actions': { pending_counts: { pending_documents: 0, submitted_documents: 0, pending_fees: 0, ready_for_allocation: 0 } },
  '/dashboard/quota-wise-stats': { quota_stats: [] },
  '/dashboard/recent-admissions': { recent_admissions: [] }
};

// Mock API responses for demonstration
api.interceptors.response.use(
  (response) => response,
  (error) => {
    // Return mock data for demo purposes
    const path = error.config.url.replace(API_BASE_URL, '');
    const mockResponse = mockResponses[path];
    
    if (mockResponse) {
      return Promise.resolve({ data: mockResponse });
    }
    
    // For other endpoints, return basic structure
    return Promise.resolve({ 
      data: { 
        message: 'Demo mode - API not connected',
        data: null 
      } 
    });
  }
);

// Masters API
export const mastersAPI = {
  // Institutions
  createInstitution: (data) => api.post('/masters/institutions', data),
  getInstitutions: () => api.get('/masters/institutions'),
  
  // Campuses
  createCampus: (data) => api.post('/masters/campuses', data),
  getCampuses: (institutionId) => api.get('/masters/campuses', { params: { institution_id: institutionId } }),
  
  // Departments
  createDepartment: (data) => api.post('/masters/departments', data),
  getDepartments: (campusId) => api.get('/masters/departments', { params: { campus_id: campusId } }),
  
  // Academic Years
  createAcademicYear: (data) => api.post('/masters/academic-years', data),
  getAcademicYears: () => api.get('/masters/academic-years'),
  
  // Programs
  createProgram: (data) => api.post('/masters/programs', data),
  getPrograms: (params) => api.get('/masters/programs', { params }),
  
  // Quotas
  createQuota: (programId, data) => api.post(`/masters/programs/${programId}/quotas`, data),
  getQuotas: (programId) => api.get(`/masters/programs/${programId}/quotas`),
};

// Applicants API
export const applicantsAPI = {
  create: (data) => api.post('/applicants', data),
  getAll: (params) => api.get('/applicants', { params }),
  getById: (id) => api.get(`/applicants/${id}`),
  update: (id, data) => api.put(`/applicants/${id}`, data),
  updateDocumentStatus: (id, data) => api.put(`/applicants/${id}/documents`, data),
  getLogs: (id) => api.get(`/applicants/${id}/logs`),
};

// Admissions API
export const admissionsAPI = {
  allocateSeat: (data) => api.post('/admissions/allocate-seat', data),
  confirmAdmission: (data) => api.post('/admissions/confirm-admission', data),
  updateFeeStatus: (data) => api.post('/admissions/update-fee-status', data),
  getAvailableSeats: (programId) => api.get(`/admissions/available-seats/${programId}`),
};

// Dashboard API
export const dashboardAPI = {
  getOverview: (params) => api.get('/dashboard/overview', { params }),
  getPendingActions: (params) => api.get('/dashboard/pending-actions', { params }),
  getQuotaStats: (params) => api.get('/dashboard/quota-wise-stats', { params }),
  getRecentAdmissions: (params) => api.get('/dashboard/recent-admissions', { params }),
};

export default api;