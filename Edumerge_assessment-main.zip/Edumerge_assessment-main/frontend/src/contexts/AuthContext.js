import React, { createContext, useContext, useState } from 'react';

const AuthContext = createContext();

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

export const AuthProvider = ({ children }) => {
  const [currentRole, setCurrentRole] = useState(() => {
    return localStorage.getItem('selectedRole') || 'admin';
  });

  const switchRole = (role) => {
    setCurrentRole(role);
    localStorage.setItem('selectedRole', role);
  };

  const value = {
    currentRole,
    switchRole,
    user: { 
      username: currentRole.charAt(0).toUpperCase() + currentRole.slice(1),
      role: currentRole 
    },
    loading: false,
    isAuthenticated: true, // Always authenticated for simplicity
    isAdmin: currentRole === 'admin',
    isAdmissionOfficer: currentRole === 'admission_officer' || currentRole === 'admin',
    isManagement: currentRole === 'management' || currentRole === 'admin'
  };

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
};