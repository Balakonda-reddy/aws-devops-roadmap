# Admission Management System

A comprehensive web-based admission management system for colleges to manage programs, quotas, applicants, seat allocation, and admission confirmation.

## Features

- **Master Setup**: Configure institutions, campuses, departments, programs, academic years, and quotas
- **Applicant Management**: Create and manage applicant records with document tracking
- **Seat Allocation**: Allocate seats based on quota availability with real-time validation
- **Admission Confirmation**: Confirm admissions after fee payment with auto-generated admission numbers
- **Dashboard**: View comprehensive statistics and pending actions
- **Role-based Access**: Admin, Admission Officer, and Management roles with different permissions

## Technology Stack

- **Backend**: Python Flask with SQLAlchemy ORM
- **Frontend**: React.js with Bootstrap
- **Database**: MySQL
- **Role Management**: Simple role-based UI switching (no authentication required)

## Project Structure

```
admission-management-system/
├── backend/
│   ├── app/
│   │   ├── models/
│   │   ├── routes/
│   │   └── services/
│   ├── requirements.txt
│   ├── run.py
│   └── .env
├── frontend/
│   ├── src/
│   │   ├── components/
│   │   ├── pages/
│   │   ├── services/
│   │   └── contexts/
│   ├── package.json
│   └── public/
├── database/
│   └── schema.sql
└── README.md
```

## Prerequisites

Before running this application, ensure you have the following installed:

- Python 3.8 or higher
- Node.js 14 or higher
- MySQL 8.0 or higher
- Git

## Quick Start (Demo Mode)

### Frontend Only Demo
1. Navigate to the frontend directory:
```bash
cd frontend
```

2. Install dependencies:
```bash
npm install
```

3. Start the development server:
```bash
npm start
```

4. Open `http://localhost:3000` in your browser
5. Use the role selector in the top navigation to switch between Admin, Admission Officer, and Management roles
6. Explore the different features available to each role

### Full Setup with Backend

### 1. Clone the Repository

```bash
git clone <repository-url>
cd admission-management-system
```

### 2. Database Setup

1. Install MySQL and create a new database:
```sql
CREATE DATABASE admission_management;
CREATE USER 'admission_user'@'localhost' IDENTIFIED BY 'your_password';
GRANT ALL PRIVILEGES ON admission_management.* TO 'admission_user'@'localhost';
FLUSH PRIVILEGES;
```

2. Run the database schema:
```bash
mysql -u admission_user -p admission_management < database/schema.sql
```

### 3. Backend Setup

1. Navigate to the backend directory:
```bash
cd backend
```

2. Create a virtual environment:
```bash
python -m venv venv
```

3. Activate the virtual environment:
   - Windows: `venv\Scripts\activate`
   - macOS/Linux: `source venv/bin/activate`

4. Install dependencies:
```bash
pip install -r requirements.txt
```

5. Configure environment variables:
   - Copy `.env` file and update database credentials
   - Update `DB_PASSWORD` and other settings as needed

6. Initialize the database:
```bash
python run.py init_db
python run.py seed_db
```

### 4. Frontend Setup

1. Navigate to the frontend directory:
```bash
cd ../frontend
```

2. Install dependencies:
```bash
npm install
```

## Running the Application

### 1. Start the Backend Server

```bash
cd backend
python run.py
```

The backend API will be available at `http://localhost:5000`

### 2. Start the Frontend Development Server

```bash
cd frontend
npm start
```

The frontend application will be available at `http://localhost:3000`

## Default Login Credentials

- **Admin**: username: `admin`, password: `admin123`
- **Admission Officer**: username: `officer`, password: `officer123`
- **Management**: username: `management`, password: `mgmt123`

**Note**: In demo mode, simply use the role selector in the navigation bar to switch between roles.

## Usage Workflow

### 1. Initial Setup (Admin)
1. Login as admin
2. Go to Master Setup
3. Create Institution → Campus → Department → Academic Year → Program → Quotas

### 2. Applicant Processing (Admission Officer)
1. Create applicant records
2. Update document status (Pending → Submitted → Verified)
3. Allocate seats based on quota availability
4. Update fee status and confirm admissions

### 3. Monitoring (Management/Admin)
1. View dashboard for overview statistics
2. Monitor quota-wise seat filling
3. Track pending actions and recent admissions

## API Endpoints

 

### Masters
- `GET /api/masters/institutions` - Get institutions
- `POST /api/masters/institutions` - Create institution
- `GET /api/masters/programs` - Get programs
- `POST /api/masters/programs` - Create program
- `GET /api/masters/programs/{id}/quotas` - Get program quotas

### Applicants
- `GET /api/applicants` - Get applicants (with pagination/filters)
- `POST /api/applicants` - Create applicant
- `GET /api/applicants/{id}` - Get applicant details
- `PUT /api/applicants/{id}` - Update applicant
- `PUT /api/applicants/{id}/documents` - Update document status

### Admissions
- `POST /api/admissions/allocate-seat` - Allocate seat
- `POST /api/admissions/confirm-admission` - Confirm admission
- `POST /api/admissions/update-fee-status` - Update fee status
- `GET /api/admissions/available-seats/{program_id}` - Get available seats

### Dashboard
- `GET /api/dashboard/overview` - Get overview statistics
- `GET /api/dashboard/pending-actions` - Get pending actions
- `GET /api/dashboard/quota-wise-stats` - Get quota statistics

 

## System Rules Implementation

1. **Quota Validation**: Total quota allocation cannot exceed program intake
2. **Seat Allocation**: Checks real-time availability before allocation
3. **Admission Number**: Auto-generated format: INST/YEAR/COURSE/DEPT/QUOTA/SEQ
4. **Fee Validation**: Admission confirmed only after fee payment
5. **Document Workflow**: Pending → Submitted → Verified sequence

## Production Deployment

For production deployment:

1. Set `FLASK_ENV=production` in backend
2. Build frontend: `npm run build`
3. Configure production database
4. Set up reverse proxy (nginx)
5. Use WSGI server (gunicorn) for backend
6. Enable HTTPS and proper security headers

## Support

For issues or questions, please check the system logs and ensure all prerequisites are properly installed and configured.