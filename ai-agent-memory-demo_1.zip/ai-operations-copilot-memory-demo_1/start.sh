#!/usr/bin/env bash
python -m streamlit run run_demo.py
