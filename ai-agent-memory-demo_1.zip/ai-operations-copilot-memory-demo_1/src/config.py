import os
from dataclasses import dataclass

from dotenv import load_dotenv
load_dotenv()


@dataclass
class Config:
    region: str = os.getenv("AWS_REGION", "us-east-1")
    model_id: str = os.getenv("BEDROCK_MODEL_ID", "us.amazon.nova-2-lite-v1:0")
    profile: str = os.getenv("AWS_PROFILE", "ai_labs")
    embedding_model: str = os.getenv("EMBEDDING_MODEL", "amazon.titan-embed-text-v2:0")
    user_id: str = os.getenv("DEMO_USER_ID", "demo-operator")
    db_path: str = "data/memory.db"
    chroma_path: str = "data/chroma"