import json
import re

import boto3


class BedrockLLM:
    def __init__(self, region, model_id, profile=""):
        self.client = boto3.Session(
            profile_name=profile or None,
            region_name=region,
        ).client("bedrock-runtime", region_name=region)
        self.model_id = model_id

    def complete(self, system, user, temperature=0, max_tokens=1200):
        response = self.client.converse(
            modelId=self.model_id,
            system=[{"text": system}],
            messages=[{"role": "user", "content": [{"text": user}]}],
            inferenceConfig={
                "temperature": temperature,
                "maxTokens": max_tokens,
                "topP": 0.9,
            },
        )
        return "".join(
            block.get("text", "") for block in response["output"]["message"]["content"]
        ).strip()

    def json_complete(self, system, user):
        raw = self.complete(system, user, 0, 800)
        match = re.search(r"\{.*\}", raw, re.S)
        if not match:
            raise ValueError("Bedrock did not return JSON: " + raw)
        return json.loads(match.group())

class MockLLM:
    def json_complete(self, system, user):
        text = user.split("CURRENT USER MESSAGE:")[-1].strip()
        message = text.lower()

        if any(x in message for x in ["thanks", "thank you", "okay"]) and len(message) < 50:
            return {
                "should_store": False,
                "memory_type": "none",
                "memory": None,
                "importance": 0.05,
                "confidence": 0.99,
                "reason": "Small talk has no durable value.",
            }

        procedural = any(
            x in message
            for x in ["always", "first", "must", "not effective", "procedure", "check "]
        )
        episodic = any(
            x in message
            for x in ["failed", "incident", "last ", "yesterday", "today", "expired", "outage"]
        )

        memory_type = "procedural" if procedural else ("episodic" if episodic else "semantic")

        return {
            "should_store": True,
            "memory_type": memory_type,
            "memory": text,
            "importance": 0.8,
            "confidence": 0.87,
            "reason": "Useful " + memory_type + " operations context.",
        }

    def complete(self, system, user, temperature=0.2, max_tokens=1200):
        memory = (
            user.split("RELEVANT LONG-TERM MEMORIES:", 1)[-1]
            .split("RECENT CONVERSATION:", 1)[0]
            .strip()
        )
        question = user.split("CURRENT USER QUESTION:")[-1].strip()

        if memory != "None":
            return (
                "Based on retrieved memory: "
                + memory.splitlines()[0].lstrip("- ")
                + "\n\nQuestion: "
                + question
            )

        history = (
            user.split("RECENT CONVERSATION:", 1)[-1]
            .split("CURRENT USER QUESTION:", 1)[0]
            .strip()
        )

        return (
            "I can use the current session context."
            if history != "None"
            else "I do not have enough stored or current-session context to answer reliably."
        )