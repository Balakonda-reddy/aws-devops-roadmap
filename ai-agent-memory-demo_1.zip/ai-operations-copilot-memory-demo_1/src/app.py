import uuid

import pandas as pd
import streamlit as st

from .config import Config
from .database import Database
from .vector_store import VectorStore
from .bedrock_client import BedrockLLM, MockLLM
from .memory_manager import MemoryManager

@st.cache_resource
def stores(d, c, e, region, profile):
    return Database(d), VectorStore(c, e, region, profile)


def fresh():
    st.session_state.sid = str(uuid.uuid4())[:8]
    st.session_state.chat = []
    st.session_state.decision = None
    st.session_state.raw = []
    st.session_state.prompt = ""

def main():
    st.set_page_config(
        page_title="AI Agent with different type of Memory",
        layout="wide",
    )
    cfg = Config()
    st.title("AI Agent with different types of Memory")
    st.caption("Evaluate → Classify → Store → Embed → Retrieve → Augment → Respond")

    if "sid" not in st.session_state:
        fresh()

    with st.sidebar:
        st.header("Demo controls")
        # mock = st.toggle("Demo/mock LLM", False)
        stm = st.toggle("Enable STM", True)
        ltm = st.toggle("Enable LTM", True)
        region = st.text_input("AWS Region", cfg.region)
        model = st.text_input("Bedrock model / inference profile ID", cfg.model_id)
        profile = st.text_input("AWS profile", cfg.profile)
        k = st.slider("Top memories", 1, 8, 4)
        th = st.slider("Minimum similarity", 0.0, 1.0, 0.25, 0.05)
        st.code("Session: " + st.session_state.sid)

        if st.button("New session", use_container_width=True):
            fresh()
            st.rerun()
  
        db, v = stores(cfg.db_path, cfg.chroma_path, cfg.embedding_model, cfg.region, cfg.profile)

        if st.button("Clear current STM", use_container_width=True):
            db.clear_session(cfg.user_id, st.session_state.sid)
            st.session_state.chat = []
            st.rerun()

        ok = st.checkbox("Allow full demo reset")

        if st.button("Reset all demo data", disabled=not ok, use_container_width=True):
            db.reset()
            v.reset()
            fresh()
            st.rerun()  

    llm = BedrockLLM(region, model, profile)
    m = MemoryManager(db, v, llm, cfg.user_id)
    a, b = st.columns([1.4, 1])

    with a:
        st.subheader("1. Conversation")
        for x in st.session_state.chat:
            with st.chat_message(x["role"]):
                st.markdown(x["content"])

        msg = st.chat_input("Talk naturally with the Operations Copilot")

        if msg:
            st.session_state.chat.append({"role": "user", "content": msg})
            h = db.history(cfg.user_id, st.session_state.sid) if stm else []

            if stm:
                db.add_message(cfg.user_id, st.session_state.sid, "user", msg)

            try:
                d = (
                    m.evaluate(st.session_state.sid, msg, h)
                    if ltm
                    else {
                        "should_store": False,
                        "memory_type": "none",
                        "reason": "LTM disabled",
                    }
                )
                
                ans, intent_data, raw, p = m.process_message(st.session_state.sid, msg, stm, ltm, k, th)

                if stm:
                    db.add_message(cfg.user_id, st.session_state.sid, "assistant", ans)

                st.session_state.chat.append({"role": "assistant", "content": ans})
                st.session_state.decision = d
                st.session_state.raw = raw
                st.session_state.prompt = p

            except Exception as e:
                st.session_state.chat.append({"role": "assistant", "content": "Error: " + str(e)})

            st.rerun()

    with b:
        st.subheader("2. Memory decision")
        if st.session_state.decision:
            st.json(st.session_state.decision)
        else:
            st.info("Send a message.")

        x = db.decisions(cfg.user_id)
        if x:
            st.dataframe(
                pd.DataFrame(x)[["should_store", "memory_type", "memory", "reason"]],
                hide_index=True,
                use_container_width=True,
            )
        else:
            st.caption("No decisions yet.")

    c, d = st.columns(2)

    with c:
        st.subheader("3. SQLite memory store")
        t = st.selectbox("Memory type", ["all", "semantic", "episodic", "procedural"])
        x = db.memories(cfg.user_id, t)
        if x:
            st.dataframe(
                pd.DataFrame(x)[
                    ["memory_type", "content", "importance", "confidence", "created_at"]
                ],
                hide_index=True,
                use_container_width=True,
            )
        else:
            st.info("LTM is empty.")

    with d:
        st.subheader("4. Retrieval inspector")
        x = st.session_state.raw
        if x:
            st.dataframe(
                pd.DataFrame(
                    [
                        {
                            "id": a["id"][:8],
                            "type": a["metadata"].get("memory_type"),
                            "memory": a["document"],
                            "similarity": round(a["similarity"], 3),
                            "accepted": a["similarity"] >= th,
                        }
                        for a in x
                    ]
                ),
                hide_index=True,
                use_container_width=True,
            )
        else:
            st.info("No retrieval yet.")

        with st.expander("Final augmented prompt"):
            st.code(st.session_state.prompt or "No prompt yet.")