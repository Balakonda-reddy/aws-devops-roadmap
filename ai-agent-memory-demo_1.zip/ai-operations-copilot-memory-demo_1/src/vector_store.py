from pathlib import Path
import json

import boto3
import chromadb


class VectorStore:
    def __init__(self, path, model_id, region, profile=""):
        Path(path).mkdir(parents=True, exist_ok=True)
        self.client = chromadb.PersistentClient(path=path)
        self.col = self.client.get_or_create_collection(
            "operations_memories",
            metadata={"hnsw:space": "cosine"},
        )
        self.model_id = model_id
        self.runtime = boto3.Session(
            profile_name=profile or None,
            region_name=region,
        ).client("bedrock-runtime", region_name=region)

    def _normalize(self, vector):
        magnitude = sum(value * value for value in vector) ** 0.5
        if not magnitude:
            return vector
        return [value / magnitude for value in vector]

    def emb(self, text):
        response = self.runtime.invoke_model(
            modelId=self.model_id,
            body=json.dumps({"inputText": text}),
            accept="application/json",
            contentType="application/json",
        )
        payload = json.loads(response["body"].read().decode("utf-8"))
        vector = payload.get("embedding")
        if not vector:
            raise ValueError(
                "Bedrock embedding response did not contain an embedding vector"
            )
        return self._normalize(vector)

    def add(self, item_id, text, metadata):
        self.col.upsert(
            ids=[item_id],
            documents=[text],
            embeddings=[self.emb(text)],
            metadatas=[metadata],
        )

    def search(self, user_id, query, k=5):
        if not self.col.count():
            return []

        results = self.col.query(
            query_embeddings=[self.emb(query)],
            n_results=min(k, self.col.count()),
            where={"user_id": user_id},
            include=["documents", "metadatas", "distances"],
        )

        output = []
        for index, item_id in enumerate(results["ids"][0]):
            distance = results["distances"][0][index]
            output.append(
                {
                    "id": item_id,
                    "document": results["documents"][0][index],
                    "metadata": results["metadatas"][0][index],
                    "distance": distance,
                    "similarity": max(0, 1 - distance),
                }
            )

        return output

    def reset(self):
        try:
            self.client.delete_collection("operations_memories")
        except Exception:
            pass

        self.col = self.client.get_or_create_collection(
            "operations_memories",
            metadata={"hnsw:space": "cosine"},
        )