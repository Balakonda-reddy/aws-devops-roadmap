import sqlite3
from datetime import datetime, timezone
from pathlib import Path

def now():
    return datetime.now(timezone.utc).isoformat()

SCHEMA = """
CREATE TABLE IF NOT EXISTS memories(
    id TEXT PRIMARY KEY,
    user_id TEXT,
    session_id TEXT,
    memory_type TEXT,
    content TEXT,
    source_message TEXT,
    importance REAL,
    confidence REAL,
    reason TEXT,
    created_at TEXT,
    status TEXT
);

CREATE TABLE IF NOT EXISTS conversation_history(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id TEXT,
    session_id TEXT,
    role TEXT,
    message TEXT,
    created_at TEXT
);

CREATE TABLE IF NOT EXISTS decisions(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id TEXT,
    session_id TEXT,
    source_message TEXT,
    should_store INTEGER,
    memory_type TEXT,
    memory TEXT,
    importance REAL,
    confidence REAL,
    reason TEXT,
    created_at TEXT
);
"""

class Database:
    def __init__(self, path):
        Path(path).parent.mkdir(parents=True, exist_ok=True)
        self.path = path
        self.run(SCHEMA, script=True)

    def conn(self):
        connection = sqlite3.connect(self.path)
        connection.row_factory = sqlite3.Row
        return connection

    def run(self, query, params=(), script=False):
        with self.conn() as connection:
            if script:
                return connection.executescript(query)
            return connection.execute(query, params)

    def add_message(self, user_id, session_id, role, message):
        self.run(
            """
            INSERT INTO conversation_history
                (user_id, session_id, role, message, created_at)
            VALUES
                (?, ?, ?, ?, ?)
            """,
            (user_id, session_id, role, message, now()),
        )

    def history(self, user_id, session_id, n=12):
        with self.conn() as connection:
            rows = connection.execute(
                """
                SELECT role, message
                FROM conversation_history
                WHERE user_id = ? AND session_id = ?
                ORDER BY id DESC
                LIMIT ?
                """,
                (user_id, session_id, n),
            ).fetchall()
        return [dict(row) for row in reversed(rows)]

    def clear_session(self, user_id, session_id):
        self.run(
            "DELETE FROM conversation_history WHERE user_id = ? AND session_id = ?",
            (user_id, session_id),
        )

    def decision(self, user_id, session_id, source_message, decision):
        self.run(
            """
            INSERT INTO decisions(
                user_id, session_id, source_message, should_store,
                memory_type, memory, importance, confidence, reason, created_at
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                user_id,
                session_id,
                source_message,
                int(bool(decision.get("should_store"))),
                decision.get("memory_type"),
                decision.get("memory"),
                decision.get("importance"),
                decision.get("confidence"),
                decision.get("reason"),
                now(),
            ),
        )

    def decisions(self, user_id):
        with self.conn() as connection:
            rows = connection.execute(
                """
                SELECT *
                FROM decisions
                WHERE user_id = ?
                ORDER BY id DESC
                LIMIT 12
                """,
                (user_id,),
            ).fetchall()
        return [dict(row) for row in rows]

    def add_memory(self, memory_data):
        self.run(
            """
            INSERT INTO memories
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            memory_data,
        )

    def memories(self, user_id, memory_type="all"):
        query = "SELECT * FROM memories WHERE user_id = ? AND status = 'active'"
        params = [user_id]

        if memory_type != "all":
            query += " AND memory_type = ?"
            params.append(memory_type)

        with self.conn() as connection:
            rows = connection.execute(query + " ORDER BY created_at DESC", params).fetchall()

        return [dict(row) for row in rows]

    def by_ids(self, user_id, ids):
        if not ids:
            return []

        placeholders = ",".join("?" for _ in ids)
        with self.conn() as connection:
            rows = connection.execute(
                f"""
                SELECT *
                FROM memories
                WHERE user_id = ? AND id IN ({placeholders})
                """,
                [user_id, *ids],
            ).fetchall()

        items = {row["id"]: dict(row) for row in rows}
        return [items[i] for i in ids if i in items]

    def reset(self):
        self.run(
            """
            DELETE FROM memories;
            DELETE FROM conversation_history;
            DELETE FROM decisions;
            """,
            script=True,
        )