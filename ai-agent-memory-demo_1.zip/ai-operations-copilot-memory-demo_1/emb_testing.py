import json
import boto3

PROFILE = "ai_labs"
REGION = "us-east-1"
MODEL_ID = "amazon.titan-embed-text-v2:0"
TEXT = "Orion Predictive Maintenance runs its daily scoring pipeline at 6 AM IST."

session = boto3.Session(profile_name=PROFILE, region_name=REGION)
client = session.client("bedrock-runtime", region_name=REGION)

payload = {
    "inputText": TEXT
}

print("Invoking model:", MODEL_ID)
print("Region:", REGION)
print("Profile:", PROFILE)

response = client.invoke_model(
    modelId=MODEL_ID,
    body=json.dumps(payload),
    contentType="application/json",
    accept="application/json",
)

data = json.loads(response["body"].read().decode("utf-8"))
print("Success")
print("Keys in response:", list(data.keys()))
print("Embedding length:", len(data.get("embedding", [])))
print("First 5 values:", data.get("embedding", [])[:5])