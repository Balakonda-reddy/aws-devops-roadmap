@echo off
python -m streamlit run run_demo.py
