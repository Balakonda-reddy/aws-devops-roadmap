# AI Operations Copilot with Memory

Local-first Streamlit demo based on the attached memory-management plan.

## Features
- AI amnesia, STM, and LTM toggles
- Automatic semantic, episodic, and procedural/reflection classification
- SQLite readable memory store
- ChromaDB semantic retrieval with local SentenceTransformers embeddings
- Amazon Bedrock Converse API plus offline mock mode
- Decision, retrieval-score, and augmented-prompt inspectors

## Setup
```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
# Copy .env.example to .env and edit configuration
streamlit run run_demo.py
```
The first use of `all-MiniLM-L6-v2` may download the model. After caching, embeddings and ChromaDB stay local.

## AWS
Use an AWS profile, IAM role, IAM Identity Center session, or the standard Boto3 credential chain. Do not put access keys in source code. Set `AWS_REGION`, `BEDROCK_MODEL_ID`, and optionally `AWS_PROFILE`. The selected model or inference profile must be available in that Region and support Converse.

## Demo script
1. STM OFF, LTM OFF: say `We support the Orion Predictive Maintenance application.` Start a new session and ask what application is supported.
2. STM ON, LTM OFF: repeat in one session, then start another session.
3. STM ON, LTM ON, enter:
   - `Orion runs its daily scoring pipeline at 6 AM IST.`
   - `AI Platform Operations provides L2 support for Orion.`
   - `Last Friday Orion failed because data warehouse credentials expired.`
   - `When Orion scoring fails, first validate source arrival, then warehouse connectivity, and finally model logs.`
   - `Okay, thanks.`
4. Start a new session and ask:
   - `Who provides second-level support?`
   - `Have we seen a similar authentication issue?`
   - `What checks should I perform when scoring fails?`
5. Reflection: `Checking model logs first was not effective. Check warehouse connectivity before model logs.`

## Security and scope
Educational demo only. Production needs authorization, encryption, retention/deletion, audit logs, PII controls, prompt-injection defenses, monitoring, evaluation, and an approved memory policy.
